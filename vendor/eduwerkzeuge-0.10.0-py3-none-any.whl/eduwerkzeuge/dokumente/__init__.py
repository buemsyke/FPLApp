"""dokumente – Text/Markdown aus PDF, DOCX und ODT gewinnen.

Zwei Ebenen:

* **leicht** (``core``): ``extrahiere_text`` / ``extrahiere_aus_datei`` liefern
  reinen Text ohne schwere Abhängigkeiten (pdftotext bzw. pypdf, Office-XML).
* **reich** (``markdown``): ``konvertiere_pdf_zu_markdown`` erzeugt Markdown mit
  Bildern, Tabellen und Mathe (benötigt ``pymupdf4llm``; Extra ``pdf-markdown``).

Beispiel:
    from eduwerkzeuge.dokumente import extrahiere_aus_datei
    text = extrahiere_aus_datei("abgabe.pdf")
"""

from .core import (
    EXTRAHIERBARE_SUFFIXE,
    extrahiere_aus_datei,
    extrahiere_text,
)

__all__ = [
    "EXTRAHIERBARE_SUFFIXE",
    "extrahiere_aus_datei",
    "extrahiere_text",
    "konvertiere_pdf_zu_markdown",
]


def __getattr__(name: str):
    # Lazy: 'konvertiere_pdf_zu_markdown' erst laden, wenn gebraucht, damit ein
    # Import von eduwerkzeuge.dokumente kein pymupdf4llm voraussetzt.
    if name == "konvertiere_pdf_zu_markdown":
        from .markdown import konvertiere_pdf_zu_markdown
        return konvertiere_pdf_zu_markdown
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
