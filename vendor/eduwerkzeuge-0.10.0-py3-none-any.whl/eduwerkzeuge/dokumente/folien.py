#!/usr/bin/env python3
"""
dokumente.folien – PDF-Foliensätze → KI-lesbares Markdown (seitenweise, mit OCR)
================================================================================

Für Tagungs-/Vortragsfolien, bei denen eine KI später den Inhalt auswerten soll,
ohne die PDFs zu öffnen. Pro PDF entsteht **eine** Markdown-Datei mit

* YAML-Kopf (``quelle``, ``seiten``, ``ocr_seiten``),
* je Seite einem Abschnitt ``## Seite N`` (zitierfähig: „Folie 7“),
* Text per ``pdftotext -layout``; Seiten mit < ``MIN_ZEICHEN`` Zeichen
  (Bildfolien, Screenshots) werden per ``tesseract`` (deu+eng) ergänzt,
* Hinweis ``_(keine Textinhalte …)_`` bei Seiten ohne erkennbaren Text,

dazu ein ``INDEX.md`` (Quelle → Markdown, Seiten, OCR-Seiten). Inhaltsgleiche
PDFs (z. B. „Datei (1).pdf“) werden per MD5 erkannt und nur einmal umgewandelt.

Grenzen: Diagramme/Fotos sind nur so weit enthalten, wie OCR Text darin findet;
OCR-Text kann Fehler enthalten. Benötigt die CLI-Programme ``pdftotext``,
``pdfinfo``, ``pdftoppm`` (poppler) und ``tesseract`` (mit ``deu``; OCR entfällt
sonst mit Warnung).

Beispiel:
    from eduwerkzeuge.dokumente.folien import konvertiere_ordner
    konvertiere_ordner(Path("tagung"))      # → tagung/markdown/*.md + INDEX.md
"""

from __future__ import annotations

import glob
import hashlib
import re
import shutil
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path

MIN_ZEICHEN = 150          # weniger Text je Seite → OCR-Versuch
OCR_DPI = "200"
LEER_HINWEIS = "_(keine Textinhalte; vermutlich nur Bild/Grafik)_"


@dataclass
class Ergebnis:
    quelle: str
    markdown: str | None        # None bei Duplikat
    duplikat_von: str | None
    seiten: int
    ocr_seiten: int


def fehlende_programme() -> list[str]:
    """Nicht gefundene Pflichtprogramme (poppler); tesseract ist optional."""
    return [p for p in ("pdftotext", "pdfinfo", "pdftoppm") if not shutil.which(p)]


def ocr_sprachen() -> str | None:
    """``deu+eng`` bzw. ``eng``; ``None`` wenn tesseract fehlt."""
    if not shutil.which("tesseract"):
        return None
    ausgabe = subprocess.run(["tesseract", "--list-langs"], capture_output=True, text=True).stdout
    return "deu+eng" if "deu" in ausgabe.split() else "eng"


def _slug(name: str) -> str:
    return re.sub(r"[^\w\-]+", "_", name).strip("_")


def _seitentext(pdf: Path, seite: int) -> str:
    t = subprocess.run(
        ["pdftotext", "-f", str(seite), "-l", str(seite), "-layout", str(pdf), "-"],
        capture_output=True, text=True,
    ).stdout
    t = re.sub(r"[ \t]+\n", "\n", t)
    return re.sub(r"\n{3,}", "\n\n", t).strip()


def _ocr(pdf: Path, seite: int, sprachen: str) -> str:
    with tempfile.TemporaryDirectory() as d:
        subprocess.run(
            ["pdftoppm", "-f", str(seite), "-l", str(seite), "-r", OCR_DPI, "-png", str(pdf), f"{d}/pg"],
            check=True, capture_output=True,
        )
        bilder = glob.glob(f"{d}/pg*.png")
        if not bilder:
            return ""
        return subprocess.run(
            ["tesseract", bilder[0], "-", "-l", sprachen], capture_output=True, text=True
        ).stdout.strip()


def konvertiere_pdf(pdf: Path, ziel_md: Path, sprachen: str | None) -> tuple[int, int]:
    """Schreibt ``ziel_md``; gibt (Seitenzahl, OCR-Seiten) zurück."""
    info = subprocess.run(["pdfinfo", str(pdf)], capture_output=True, text=True).stdout
    m = re.search(r"Pages:\s+(\d+)", info)
    if not m:
        raise ValueError(f"Keine Seitenzahl lesbar: {pdf.name}")
    n = int(m.group(1))
    titel = (re.search(r"Title:\s+(.*)", info) or [None, ""])[1].strip()

    teile, ocr_n = [], 0
    for p in range(1, n + 1):
        text = _seitentext(pdf, p)
        if len(text) < MIN_ZEICHEN and sprachen:
            o = _ocr(pdf, p, sprachen)
            if len(o) > len(text):
                text, ocr_n = o, ocr_n + 1
        teile.append(f"## Seite {p}\n\n{text or LEER_HINWEIS}")

    kopf = f"---\nquelle: {pdf.name}\nseiten: {n}\nocr_seiten: {ocr_n}\n---\n\n# {titel or pdf.stem}\n\n"
    ziel_md.write_text(kopf + "\n\n".join(teile) + "\n", encoding="utf-8")
    return n, ocr_n


def schreibe_index(ziel: Path, ergebnisse: list[Ergebnis], titel: str) -> Path:
    zeilen = [
        f"# Index: {titel} (PDF -> Markdown)\n",
        "Jede Datei enthält seitenweise (`## Seite N`) den extrahierten Text. Seiten mit wenig Text "
        "wurden per OCR (tesseract) ergänzt; reine Grafiken/Diagramme/Screenshots sind nur soweit "
        "enthalten, wie OCR sie erkennt.\n",
        "| Quelle (PDF) | Markdown | Seiten | OCR-Seiten |",
        "|---|---|---|---|",
    ]
    for e in ergebnisse:
        md = e.markdown or f"(Duplikat von {e.duplikat_von})"
        zeilen.append(f"| {e.quelle} | {md} | {e.seiten or ''} | {e.ocr_seiten or ''} |")
    pfad = ziel / "INDEX.md"
    pfad.write_text("\n".join(zeilen) + "\n", encoding="utf-8")
    return pfad


def konvertiere_ordner(ordner: Path, ausgabe: Path | None = None, titel: str | None = None) -> list[Ergebnis]:
    """Alle ``*.pdf`` in ``ordner`` → ``ausgabe`` (Standard ``ordner/markdown``) + INDEX.md."""
    ordner = Path(ordner)
    fehlt = fehlende_programme()
    if fehlt:
        raise RuntimeError("Fehlende Programme (poppler-utils): " + ", ".join(fehlt))
    ausgabe = Path(ausgabe) if ausgabe else ordner / "markdown"
    ausgabe.mkdir(parents=True, exist_ok=True)
    sprachen = ocr_sprachen()

    gesehen: dict[str, str] = {}
    ergebnisse: list[Ergebnis] = []
    for pdf in sorted(ordner.glob("*.pdf")):
        h = hashlib.md5(pdf.read_bytes()).hexdigest()
        if h in gesehen:
            ergebnisse.append(Ergebnis(pdf.name, None, gesehen[h], 0, 0))
            continue
        md_name = _slug(pdf.stem) + ".md"
        gesehen[h] = md_name
        n, o = konvertiere_pdf(pdf, ausgabe / md_name, sprachen)
        ergebnisse.append(Ergebnis(pdf.name, md_name, None, n, o))
    schreibe_index(ausgabe, ergebnisse, titel or ordner.resolve().name)
    return ergebnisse
