#!/usr/bin/env python3
"""CLI für die Dokument-Werkzeuge: ``edu-dokumente``.

  edu-dokumente text abgabe.pdf            # reinen Text extrahieren (leicht)
  edu-dokumente text bericht.docx -o b.txt # Text in Datei schreiben
  edu-dokumente md ./Richtlinien           # alle PDFs im Ordner → Markdown
  edu-dokumente md skript.pdf              # eine PDF → skript.md (reich)
  edu-dokumente folien ./tagung            # Foliensätze → markdown/*.md + INDEX.md
                                           # (seitenweise, OCR für Bildfolien, Duplikate erkannt)

``text`` braucht nur pdftotext/pypdf; ``folien`` poppler + (optional) tesseract; ``md`` benötigt ``pymupdf4llm``
(``pip install "eduwerkzeuge[pdf-markdown]"``).
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from .core import extrahiere_aus_datei


def _cmd_text(args) -> int:
    pfad = Path(args.input)
    if not pfad.exists():
        print(f"Fehler: Datei nicht gefunden: {pfad}", file=sys.stderr)
        return 1
    text = extrahiere_aus_datei(pfad)
    if text is None:
        print(f"Kein Text extrahierbar aus: {pfad}", file=sys.stderr)
        return 1
    if args.output:
        Path(args.output).write_text(text, encoding="utf-8")
        print(f"Text geschrieben: {args.output}")
    else:
        sys.stdout.write(text)
    return 0


def _cmd_folien(args) -> int:
    from . import folien

    ordner = Path(args.ordner)
    if not ordner.is_dir():
        print(f"Fehler: Ordner nicht gefunden: {ordner}", file=sys.stderr)
        return 1
    if folien.ocr_sprachen() is None:
        print("Hinweis: tesseract fehlt – Bildseiten bleiben ohne OCR.", file=sys.stderr)
    try:
        erg = folien.konvertiere_ordner(ordner, Path(args.output) if args.output else None, args.titel)
    except RuntimeError as exc:
        print(f"Fehler: {exc}", file=sys.stderr)
        return 1
    for e in erg:
        print(f"  {e.quelle} -> {e.markdown or 'Duplikat von ' + e.duplikat_von}"
              + (f" ({e.seiten} S., {e.ocr_seiten} OCR)" if e.markdown else ""))
    print(f"Fertig: {sum(1 for e in erg if e.markdown)} Dateien + INDEX.md")
    return 0


def pdf_zu_md_main(argv: list[str] | None = None, default_ziel: Path | None = None) -> int:
    """Konvertiert PDF(s) zu Markdown – verhält sich wie das frühere
    ``konvertiere_pdf_zu_md.py`` (inkl. Ausgaben). ``default_ziel`` setzt das
    Ziel, wenn kein Argument übergeben wird (Shims geben hier ihren Projektpfad)."""
    from . import markdown as md_mod

    ziel = Path(argv[0]).resolve() if argv else (
        default_ziel.resolve() if default_ziel else Path.cwd()
    )

    fehlend = md_mod.pruefe_abhaengigkeiten()
    if fehlend:
        print("Fehlende Pakete. Bitte installieren mit:")
        print(f"  pip install {' '.join(fehlend)}")
        return 1

    try:
        pdfs = md_mod.pdfs_ermitteln(ziel)
    except (FileNotFoundError, ValueError) as exc:
        print(f"Fehler: {exc}", file=sys.stderr)
        return 1
    if not pdfs:
        print(f"Keine PDF-Dateien in '{ziel}' gefunden.")
        return 0

    ordner = pdfs[0].parent
    bild_ordner = ordner / "bilder"
    print(f"Zielordner : {ordner}")
    print(f"Bildordner : {bild_ordner}")
    print(f"PDFs gefunden: {len(pdfs)}\n")

    erfolgreich = 0
    for pdf in pdfs:
        try:
            print(f"  Verarbeite: {pdf.name}")
            md_pfad = md_mod.konvertiere_pdf_zu_markdown(pdf, bild_ordner)
            seiten = md_mod.seitenanzahl(pdf)
            bilder = len(list(bild_ordner.glob(f"{pdf.stem}*")))
            print(f"    ✓ {md_pfad.name}  ({seiten} Seiten, {bilder} Bilder extrahiert)")
            erfolgreich += 1
        except Exception as exc:
            print(f"    ✗ Fehler bei {pdf.name}: {exc}")

    print(f"\nFertig: {erfolgreich}/{len(pdfs)} Dateien konvertiert.")
    if bild_ordner.exists():
        bilder_gesamt = len(list(bild_ordner.glob("*.png")))
        print(f"Bilder gesamt: {bilder_gesamt} → {bild_ordner}")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="edu-dokumente",
        description="Text/Markdown aus PDF, DOCX und ODT gewinnen.",
    )
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_text = sub.add_parser("text", help="reinen Text extrahieren (leicht)")
    p_text.add_argument("input", help="Eingabedatei (.pdf, .docx, .odt)")
    p_text.add_argument("-o", "--output", help="Ausgabe-Textdatei (Standard: stdout)")
    p_text.set_defaults(func=_cmd_text)

    p_md = sub.add_parser("md", help="PDF(s) → Markdown (benötigt pymupdf4llm)")
    p_md.add_argument("ziel", nargs="?", help="PDF-Datei oder Ordner (Standard: aktuelles Verzeichnis)")

    p_fo = sub.add_parser("folien", help="Foliensätze (PDF-Ordner) → seitenweises Markdown mit OCR + INDEX.md")
    p_fo.add_argument("ordner", help="Ordner mit PDFs")
    p_fo.add_argument("-o", "--output", help="Ausgabeordner (Standard: <ordner>/markdown)")
    p_fo.add_argument("--titel", help="Titel für INDEX.md (Standard: Ordnername)")
    p_fo.set_defaults(func=_cmd_folien)

    args = parser.parse_args(argv)

    if args.cmd == "md":
        return pdf_zu_md_main([args.ziel] if args.ziel else None)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
