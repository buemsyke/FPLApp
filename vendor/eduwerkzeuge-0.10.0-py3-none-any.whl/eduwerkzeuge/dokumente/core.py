#!/usr/bin/env python3
"""
dokumente – Text aus PDF/DOCX/ODT gewinnen (leichtgewichtig)
============================================================

Eine **abhängigkeitsarme** Text-Extraktion: zuerst das verbreitete CLI-Werkzeug
``pdftotext`` (poppler), sonst ``pypdf``/``PyPDF2``, und für Office-Formate ein
direkter Zugriff auf das eingebettete XML (kein ``python-docx``/``odfpy`` nötig).

Gibt immer reinen Text (oder ``None``) zurück – ohne Bilder, ohne Layout. Für
eine reichhaltige Markdown-Konvertierung (Tabellen, Bilder, Mathe) siehe
``eduwerkzeuge.dokumente.markdown`` (benötigt ``pymupdf4llm``).

Beispiel:
    from eduwerkzeuge.dokumente import extrahiere_text, extrahiere_aus_datei

    text = extrahiere_aus_datei(Path("abgabe.pdf"))        # liest die Datei
    text = extrahiere_text(rohbytes, ".docx")              # aus rohen Bytes
"""

from __future__ import annotations

import html as _html
import io
import importlib
import re
import shutil
import subprocess
import tempfile
from pathlib import Path

# Dateiendungen, deren Inhalt diese Modul-Funktionen extrahieren können.
EXTRAHIERBARE_SUFFIXE = {".pdf", ".docx", ".odt"}


def extrahiere_text(data: bytes, suffix: str) -> str | None:
    """Versucht, lesbaren Text aus rohen Datei-Bytes zu gewinnen.

    ``suffix`` ist die Dateiendung inkl. Punkt (z. B. ``".pdf"``). Gibt den Text
    zurück oder ``None``, wenn keine Extraktion möglich war.
    """
    suffix = suffix.lower()
    if suffix == ".pdf":
        return _pdf_text(data)
    if suffix in (".docx", ".odt"):
        return _office_xml_text(data, suffix)
    return None


def extrahiere_aus_datei(pfad: str | Path) -> str | None:
    """Wie ``extrahiere_text``, liest die Datei aber selbst von ``pfad``."""
    pfad = Path(pfad)
    try:
        return extrahiere_text(pfad.read_bytes(), pfad.suffix)
    except OSError:
        return None


def _pdf_text(data: bytes) -> str | None:
    # 1) poppler 'pdftotext' (häufig vorhanden, robust)
    if shutil.which("pdftotext"):
        try:
            with tempfile.NamedTemporaryFile(suffix=".pdf") as tf:
                tf.write(data)
                tf.flush()
                out = subprocess.run(
                    ["pdftotext", "-q", "-enc", "UTF-8", tf.name, "-"],
                    capture_output=True, timeout=60,
                )
            if out.returncode == 0 and out.stdout.strip():
                return out.stdout.decode("utf-8", "replace")
        except Exception:
            pass
    # 2) pypdf / PyPDF2, falls installiert
    for modname in ("pypdf", "PyPDF2"):
        try:
            mod = importlib.import_module(modname)
            reader = mod.PdfReader(io.BytesIO(data))
            return "\n".join((p.extract_text() or "") for p in reader.pages)
        except Exception:
            continue
    return None


def _office_xml_text(data: bytes, suffix: str) -> str | None:
    import zipfile
    member = "word/document.xml" if suffix == ".docx" else "content.xml"
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            xml = z.read(member).decode("utf-8", "replace")
    except Exception:
        return None
    xml = re.sub(r"</w:p>|</text:p>|</text:h>", "\n", xml)
    text = re.sub(r"<[^>]+>", "", xml)
    return _html.unescape(text)
