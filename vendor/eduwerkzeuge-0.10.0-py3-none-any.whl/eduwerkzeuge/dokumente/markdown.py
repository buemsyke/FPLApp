#!/usr/bin/env python3
"""
dokumente.markdown – PDF → Markdown (reich: Bilder, Tabellen, Mathe)
====================================================================

Konvertiert PDF-Dateien in Markdown mit ``pymupdf4llm``:
  - Bilder werden extern in einen Unterordner ``bilder/`` gespeichert
  - Tabellen werden als GFM-Markdown-Tabellen dargestellt
  - mathematische Ausdrücke werden als KaTeX (``$…$``) eingebettet
  - Überschriften-Erkennung über Schriftgröße

Benötigt ``pymupdf`` und ``pymupdf4llm`` (optionales Extra ``pdf-markdown``):
    pip install "eduwerkzeuge[pdf-markdown]"

Beispiel:
    from eduwerkzeuge.dokumente.markdown import konvertiere_pdf_zu_markdown
    md_pfad = konvertiere_pdf_zu_markdown(Path("skript.pdf"))
"""

from __future__ import annotations

import os
import re
from datetime import date
from pathlib import Path


# ─────────────────────────────────────────────────────────────────────────────
# Abhängigkeiten prüfen
# ─────────────────────────────────────────────────────────────────────────────

def pruefe_abhaengigkeiten() -> list[str]:
    """Gibt die Liste fehlender Pakete zurück (leer = alles vorhanden)."""
    fehlend = []
    try:
        import fitz  # noqa: F401  (PyMuPDF)
    except ImportError:
        fehlend.append("pymupdf")
    try:
        import pymupdf4llm  # noqa: F401
    except ImportError:
        fehlend.append("pymupdf4llm")
    return fehlend


# ─────────────────────────────────────────────────────────────────────────────
# Nachbearbeitung: mathematische Ausdrücke erkennen und auszeichnen
# ─────────────────────────────────────────────────────────────────────────────

# Muster für Inline-Mathematik, die pymupdf4llm noch nicht umwandelt
_MATH_MUSTER = [
    # Brüche (z. B. "a/b" mit Operatoren drumherum)
    (re.compile(r'(?<![`$])\b(\d+)\s*/\s*(\d+)\b(?![`$])'), r'$\1/\2$'),
    # Potenzen mit ^ (z. B. "x^2", "10^-3")
    (re.compile(r'(?<![`$\\])\b([A-Za-z0-9]+)\^([A-Za-z0-9\-\+]+)\b(?![`$])'), r'$\1^{\2}$'),
    # Griechische / Sonderzeichen und typische Formelzeichen
    (re.compile(r'(?<!\$)(≤|≥|≠|≈|±|∞|∑|∏|∫|∂|√|∇|∈|∉|⊆|⊂|⊃|∪|∩|∀|∃|→|⟶|⇒|⟹|↔|⟺)(?!\$)'), r'$\1$'),
]


def mathematik_auszeichnen(text: str) -> str:
    """Umschließt erkannte mathematische Ausdrücke mit $…$ (KaTeX/LaTeX)."""
    # Bereits markierte Blöcke ($$…$$, $…$, `…`) nicht doppelt bearbeiten
    schutzbereich_re = re.compile(r'(\$\$.*?\$\$|\$[^$\n]+?\$|`[^`]+`)', re.DOTALL)
    teile = schutzbereich_re.split(text)

    ergebnis = []
    for i, teil in enumerate(teile):
        if i % 2 == 1:          # geschützter Bereich → unverändert
            ergebnis.append(teil)
        else:
            for muster, ersatz in _MATH_MUSTER:
                teil = muster.sub(ersatz, teil)
            ergebnis.append(teil)
    return "".join(ergebnis)


# ─────────────────────────────────────────────────────────────────────────────
# Kopfzeilen-Metadaten
# ─────────────────────────────────────────────────────────────────────────────

def kopfzeile_erstellen(pdf_pfad: Path) -> str:
    """Erstellt einen YAML-Frontmatter-Block mit Dateiname und Konvertierungsdatum."""
    return (
        f"---\n"
        f"quelle: {pdf_pfad.name}\n"
        f"konvertiert: {date.today().isoformat()}\n"
        f"---\n\n"
    )


# ─────────────────────────────────────────────────────────────────────────────
# Hauptfunktion: eine PDF-Datei konvertieren
# ─────────────────────────────────────────────────────────────────────────────

def konvertiere_pdf_zu_markdown(
    pdf_pfad: Path,
    bild_ordner: Path | None = None,
    frontmatter: bool = True,
) -> Path:
    """Konvertiert eine PDF-Datei in Markdown und schreibt ``<pdf>.md``.

    Parameters
    ----------
    pdf_pfad:    Pfad zur PDF-Datei.
    bild_ordner: Ordner für extrahierte Bilder (Default: ``<pdf-ordner>/bilder``).
    frontmatter: YAML-Kopfzeile (quelle/konvertiert) voranstellen.

    Returns
    -------
    Pfad zur erzeugten Markdown-Datei.
    """
    import pymupdf4llm

    pdf_pfad = Path(pdf_pfad)
    if bild_ordner is None:
        bild_ordner = pdf_pfad.parent / "bilder"
    bild_ordner = Path(bild_ordner)
    bild_ordner.mkdir(parents=True, exist_ok=True)

    # pymupdf4llm konvertiert Seiten zu Markdown, extrahiert Bilder und
    # erkennt tabellenartige Strukturen als GFM-Tabellen.
    md_text: str = pymupdf4llm.to_markdown(
        str(pdf_pfad),
        write_images=True,
        image_path=str(bild_ordner),
        image_format="png",
        show_progress=False,
    )

    # Bild-Pfade auf relative Verweise anpassen (relativ zur MD-Datei)
    try:
        rel_bild_pfad = bild_ordner.relative_to(pdf_pfad.parent)
    except ValueError:
        rel_bild_pfad = bild_ordner
    md_text = md_text.replace(str(bild_ordner) + os.sep, str(rel_bild_pfad) + "/")
    md_text = md_text.replace(str(bild_ordner) + "/", str(rel_bild_pfad) + "/")

    md_text = mathematik_auszeichnen(md_text)
    if frontmatter:
        md_text = kopfzeile_erstellen(pdf_pfad) + md_text

    md_pfad = pdf_pfad.with_suffix(".md")
    md_pfad.write_text(md_text, encoding="utf-8")
    return md_pfad


def seitenanzahl(pdf_pfad: Path) -> int:
    """Anzahl der Seiten einer PDF (0 bei Fehler/ohne PyMuPDF)."""
    try:
        import fitz
        with fitz.open(str(pdf_pfad)) as doc:
            return doc.page_count
    except Exception:
        return 0


def pdfs_ermitteln(ziel: Path) -> list[Path]:
    """Gibt alle PDF-Dateien im Zielordner zurück (oder die Datei selbst).

    Wirft ``FileNotFoundError`` / ``ValueError`` statt das Programm zu beenden,
    damit Aufrufer (CLI, Shim) die Fehlerbehandlung steuern können.
    """
    ziel = Path(ziel)
    if ziel.is_file():
        if ziel.suffix.lower() != ".pdf":
            raise ValueError(f"'{ziel}' ist keine PDF-Datei.")
        return [ziel]
    if ziel.is_dir():
        return sorted(ziel.glob("*.pdf"))
    raise FileNotFoundError(f"'{ziel}' nicht gefunden.")
