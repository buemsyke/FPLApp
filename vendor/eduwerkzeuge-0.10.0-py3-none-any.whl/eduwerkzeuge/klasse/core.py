#!/usr/bin/env python3
"""
klasse – Klassenaggregation: Ergebnis-CSVs auswerten (Statistik, Notenspiegel)
==============================================================================

Wertet Punktelisten einer Klasse aus – als Ergänzung zur Einzelnote
(``bewertung``). Zwei Eingabeformate werden automatisch erkannt:

1. **Moodle-Bewertungsexport** (Bewertungen → Export → CSV/Textdatei):
   Spalten ``Vorname``/``Nachname`` plus Bewertungsspalten. Metadaten-Spalten
   (E-Mail, ID, …) werden ignoriert; ``-`` gilt als „keine Abgabe".
2. **Generisches CSV**: erste Spalte Name/Pseudonym, weitere Spalten Punkte
   (je Kriterium oder gesamt). Dezimalkomma und ``;``-Trenner sind erlaubt.

Kernfunktionen (reine Funktionen, gut testbar):
  * ``lade_ergebnisse``  – CSV → (Namen, {Spalte: [Punkte|None, …]})
  * ``statistik``        – Mittel/Median/Stdabw/Min/Max einer Punkteliste
  * ``notenspiegel``     – Verteilung über Notenpunkte (15-P.-System)
  * ``klassenbericht``   – kompletter Bericht als Datenstruktur
  * ``bericht_markdown`` – Bericht als Markdown-Text

Beispiel:
    from eduwerkzeuge.klasse import lade_ergebnisse, klassenbericht
    namen, spalten = lade_ergebnisse(Path("ergebnisse.csv"))
    bericht = klassenbericht(namen, spalten, max_punkte={"Gesamt": 60})
"""

from __future__ import annotations

import csv
import statistics
from pathlib import Path

from eduwerkzeuge.bewertung import NOTENPUNKTE_15, noten_label, notenpunkte

# Spalten des Moodle-Bewertungsexports, die keine Punkte enthalten.
_MOODLE_META = {
    "vorname", "nachname", "e-mail-adresse", "id-nummer", "institution",
    "abteilung", "gruppe", "gruppen", "benutzername",
    "zuletzt aus diesem kurs geholt", "zuletzt heruntergeladen aus diesem kurs",
}


# -------------------- Einlesen --------------------

def _zahl(wert: str) -> float | None:
    """Punktwert aus einer CSV-Zelle: Dezimalkomma erlaubt, ``-``/leer → None."""
    s = (wert or "").strip().replace(" ", "")
    if s in ("", "-", "–"):
        return None
    try:
        return float(s.replace(",", "."))
    except ValueError:
        return None


def _dialekt(text: str) -> csv.Dialect | type[csv.excel]:
    try:
        return csv.Sniffer().sniff(text[:4096], delimiters=",;\t")
    except csv.Error:
        return csv.excel


def lade_ergebnisse(pfad: Path) -> tuple[list[str], dict[str, list[float | None]]]:
    """CSV einlesen → (Namen, {Punktspalte: Werte in Namensreihenfolge}).

    Erkennt den Moodle-Bewertungsexport an ``Vorname``+``Nachname``; sonst gilt
    die erste Spalte als Name/Pseudonym. Spalten ohne einen einzigen Zahlwert
    werden verworfen (Metadaten).
    """
    text = pfad.read_text(encoding="utf-8-sig")
    zeilen = list(csv.reader(text.splitlines(), _dialekt(text)))
    zeilen = [z for z in zeilen if any(feld.strip() for feld in z)]
    if len(zeilen) < 2:
        raise ValueError(f"{pfad.name}: keine Datenzeilen gefunden (Kopf + mind. 1 Zeile nötig).")

    kopf = [h.strip() for h in zeilen[0]]
    kopf_lc = [h.lower() for h in kopf]
    daten = zeilen[1:]

    if "vorname" in kopf_lc and "nachname" in kopf_lc:  # Moodle-Export
        i_vor, i_nach = kopf_lc.index("vorname"), kopf_lc.index("nachname")
        namen = [f"{z[i_vor].strip()} {z[i_nach].strip()}".strip() for z in daten]
        kandidaten = [i for i, h in enumerate(kopf_lc)
                      if h not in _MOODLE_META and i not in (i_vor, i_nach)]
    else:  # generisch: Spalte 0 = Name/Pseudonym
        namen = [z[0].strip() for z in daten]
        kandidaten = list(range(1, len(kopf)))

    spalten: dict[str, list[float | None]] = {}
    for i in kandidaten:
        werte = [_zahl(z[i]) if i < len(z) else None for z in daten]
        if any(w is not None for w in werte):  # reine Text-/Leerspalten verwerfen
            spalten[kopf[i]] = werte

    if not spalten:
        raise ValueError(f"{pfad.name}: keine Punktspalte gefunden.")
    return namen, spalten


# -------------------- Auswertung --------------------

def statistik(werte: list[float | None]) -> dict:
    """Kennzahlen einer Punkteliste; ``None`` (keine Abgabe) wird ausgewiesen."""
    xs = [w for w in werte if w is not None]
    if not xs:
        return {"n": 0, "fehlend": len(werte)}
    return {
        "n": len(xs),
        "fehlend": len(werte) - len(xs),
        "mittel": statistics.fmean(xs),
        "median": statistics.median(xs),
        "stdabw": statistics.stdev(xs) if len(xs) > 1 else 0.0,
        "min": min(xs),
        "max": max(xs),
    }


def notenspiegel(werte: list[float | None], max_punkte: float) -> dict:
    """Verteilung über Notenpunkte (0–15) inkl. Schnitt und Bestehensquote.

    „Bestanden" = mindestens 4 Notenpunkte (Note 4-), die übliche Grenze im
    15-Punkte-System.
    """
    xs = [w for w in werte if w is not None]
    verteilung = {np: 0 for np in range(15, -1, -1)}
    for w in xs:
        verteilung[notenpunkte(w, max_punkte)] += 1
    nps = [notenpunkte(w, max_punkte) for w in xs]
    return {
        "verteilung": verteilung,
        "labels": {np: label for _, np, label in NOTENPUNKTE_15},
        "schnitt_notenpunkte": statistics.fmean(nps) if nps else None,
        "bestanden": sum(1 for np in nps if np >= 4),
        "n": len(xs),
    }


def klassenbericht(
    namen: list[str],
    spalten: dict[str, list[float | None]],
    max_punkte: dict[str, float] | None = None,
    gesamt: str | None = None,
) -> dict:
    """Kompletter Klassenbericht als Datenstruktur.

    ``max_punkte``: bekannte Maxima je Spalte (für Erfüllungsquote/Notenspiegel).
    Ohne Angabe dient das beobachtete Spaltenmaximum als Näherung (im Bericht
    gekennzeichnet). ``gesamt``: Spalte für Notenspiegel und Auffälligkeiten
    (Default: letzte Spalte).
    """
    max_punkte = max_punkte or {}
    if gesamt is None:
        gesamt = list(spalten)[-1]
    if gesamt not in spalten:
        raise ValueError(f"Gesamtspalte '{gesamt}' nicht gefunden. Vorhanden: {', '.join(spalten)}")

    kriterien = {}
    for name, werte in spalten.items():
        st = statistik(werte)
        mx = max_punkte.get(name)
        geschaetzt = mx is None
        if geschaetzt and st.get("n"):
            mx = st["max"]
        quote = (st["mittel"] / mx * 100) if (st.get("n") and mx) else None
        kriterien[name] = {**st, "max_punkte": mx, "max_geschaetzt": geschaetzt,
                           "erfuellung_prozent": quote}

    # Schwächste Kriterien: niedrigste mittlere Erfüllungsquote (ohne Gesamtspalte).
    quoten = [(n, k["erfuellung_prozent"]) for n, k in kriterien.items()
              if n != gesamt and k["erfuellung_prozent"] is not None]
    schwaechste = [n for n, _ in sorted(quoten, key=lambda t: t[1])[:3]]

    # Auffälligkeiten: > 1 Stdabw unter dem Mittel der Gesamtspalte.
    g_werte, g_stat = spalten[gesamt], statistik(spalten[gesamt])
    auffaellig = []
    if g_stat.get("n", 0) > 1 and g_stat["stdabw"] > 0:
        grenze = g_stat["mittel"] - g_stat["stdabw"]
        auffaellig = [namen[i] for i, w in enumerate(g_werte)
                      if w is not None and w < grenze]
    ohne_abgabe = [namen[i] for i, w in enumerate(g_werte) if w is None]

    spiegel = None
    if gesamt in max_punkte:
        spiegel = notenspiegel(g_werte, max_punkte[gesamt])

    return {
        "n_lernende": len(namen),
        "gesamt_spalte": gesamt,
        "kriterien": kriterien,
        "schwaechste_kriterien": schwaechste,
        "auffaellige_lernende": auffaellig,
        "ohne_abgabe": ohne_abgabe,
        "notenspiegel": spiegel,
    }


# -------------------- Markdown-Ausgabe --------------------

def _f(x: float | None, nk: int = 1) -> str:
    return "–" if x is None else f"{x:.{nk}f}".replace(".", ",")


def bericht_markdown(bericht: dict, titel: str = "Klassenbericht") -> str:
    """Bericht als Markdown (für Ablage neben den Abgaben oder Weitergabe)."""
    z: list[str] = [f"# {titel}", ""]
    z.append(f"Lernende: **{bericht['n_lernende']}** · Gesamtspalte: `{bericht['gesamt_spalte']}`")
    z += ["", "## Kriterien", "",
          "| Kriterium | n | fehlt | Mittel | Median | Stdabw | Min | Max | Erfüllung |",
          "|---|---|---|---|---|---|---|---|---|"]
    for name, k in bericht["kriterien"].items():
        if not k.get("n"):
            z.append(f"| {name} | 0 | {k['fehlend']} | – | – | – | – | – | – |")
            continue
        stern = " *" if k["max_geschaetzt"] else ""
        quote = f"{_f(k['erfuellung_prozent'])} %{stern}" if k["erfuellung_prozent"] is not None else "–"
        z.append(f"| {name} | {k['n']} | {k['fehlend']} | {_f(k['mittel'])} | {_f(k['median'])} "
                 f"| {_f(k['stdabw'])} | {_f(k['min'])} | {_f(k['max'])} | {quote} |")
    if any(k["max_geschaetzt"] for k in bericht["kriterien"].values()):
        z += ["", "\\* Maximum nicht angegeben – Erfüllung relativ zum besten erreichten Wert."]

    if bericht["schwaechste_kriterien"]:
        z += ["", "## Schwächste Kriterien (niedrigste Erfüllung)", ""]
        z += [f"{i}. {n}" for i, n in enumerate(bericht["schwaechste_kriterien"], 1)]

    sp = bericht["notenspiegel"]
    if sp:
        z += ["", "## Notenspiegel (Gesamtspalte)", "",
              "| Notenpunkte | Note | Anzahl |", "|---|---|---|"]
        for np in range(15, -1, -1):
            anz = sp["verteilung"][np]
            if anz:
                z.append(f"| {np:02d} | {sp['labels'][np]} | {anz} |")
        z += ["", f"Schnitt: **{_f(sp['schnitt_notenpunkte'])} Notenpunkte** · "
                  f"bestanden (≥ 4 NP): **{sp['bestanden']}/{sp['n']}**"]

    if bericht["auffaellige_lernende"]:
        z += ["", "## Auffälligkeiten (> 1 Stdabw unter dem Klassenmittel)", ""]
        z += [f"- {n}" for n in bericht["auffaellige_lernende"]]
    if bericht["ohne_abgabe"]:
        z += ["", "## Ohne Ergebnis in der Gesamtspalte", ""]
        z += [f"- {n}" for n in bericht["ohne_abgabe"]]

    z += ["", "---", "*Erzeugt mit `edu-klasse` (eduwerkzeuge). Datenschutz: für Weitergabe "
              "vorab pseudonymisieren (`edu-anonymisieren`).*", ""]
    return "\n".join(z)
