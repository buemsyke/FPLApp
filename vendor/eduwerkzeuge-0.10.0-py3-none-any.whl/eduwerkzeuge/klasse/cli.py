#!/usr/bin/env python3
"""CLI für die Klassenaggregation: ``edu-klasse``.

  edu-klasse bericht ergebnisse.csv                         # Konsole
  edu-klasse bericht ergebnisse.csv --max Gesamt=60         # + Notenspiegel
  edu-klasse bericht ergebnisse.csv --gesamt "Kurs gesamt" --md bericht.md

Eingabe: Moodle-Bewertungsexport (CSV) oder generisches CSV
(Spalte 1 = Name/Pseudonym, weitere Spalten = Punkte). Automatische Erkennung.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from .core import bericht_markdown, klassenbericht, lade_ergebnisse


def _parse_max(angaben: list[str]) -> dict[str, float]:
    """``SPALTE=WERT``-Paare → dict; nackte Zahl gilt für die Gesamtspalte."""
    maxima: dict[str, float] = {}
    for a in angaben:
        if "=" in a:
            spalte, wert = a.rsplit("=", 1)
            maxima[spalte.strip()] = float(wert.replace(",", "."))
        else:
            maxima["__gesamt__"] = float(a.replace(",", "."))
    return maxima


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        prog="edu-klasse",
        description="Klassenergebnisse aggregieren (Statistik, Notenspiegel, Auffälligkeiten).",
    )
    sub = p.add_subparsers(dest="cmd", required=True)

    b = sub.add_parser("bericht", help="Ergebnis-CSV auswerten")
    b.add_argument("csv", type=Path, help="Ergebnis-CSV (Moodle-Export oder generisch)")
    b.add_argument("--gesamt", help="Spalte für Notenspiegel/Auffälligkeiten (Default: letzte)")
    b.add_argument("--max", action="append", default=[], metavar="SPALTE=WERT",
                   help="Maximalpunkte je Spalte (mehrfach möglich); nackte Zahl = Gesamtspalte")
    b.add_argument("--md", type=Path, metavar="DATEI",
                   help="Bericht zusätzlich als Markdown-Datei schreiben")

    args = p.parse_args(argv)
    if args.cmd != "bericht":
        return 1

    try:
        namen, spalten = lade_ergebnisse(args.csv)
        maxima = _parse_max(args.max)
        gesamt = args.gesamt or list(spalten)[-1]
        if "__gesamt__" in maxima:
            maxima[gesamt] = maxima.pop("__gesamt__")
        bericht = klassenbericht(namen, spalten, max_punkte=maxima, gesamt=gesamt)
    except FileNotFoundError:
        print(f"FEHLER: Datei nicht gefunden: {args.csv}", file=sys.stderr)
        return 1
    except ValueError as e:
        print(f"FEHLER: {e}", file=sys.stderr)
        return 1

    md = bericht_markdown(bericht, titel=f"Klassenbericht – {args.csv.stem}")
    print(md)
    if args.md:
        args.md.write_text(md, encoding="utf-8")
        print(f"→ geschrieben: {args.md}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
