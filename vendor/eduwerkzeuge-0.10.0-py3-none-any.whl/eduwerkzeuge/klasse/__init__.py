"""klasse – Klassenaggregation: Ergebnis-CSVs auswerten.

Ergänzt ``bewertung`` (Einzelnote) um die Klassenebene: Statistik je Kriterium,
Notenspiegel (15-P.-System), schwächste Kriterien, Auffälligkeiten.

Beispiel:
    from eduwerkzeuge.klasse import lade_ergebnisse, klassenbericht, bericht_markdown
"""

from .core import (
    bericht_markdown,
    klassenbericht,
    lade_ergebnisse,
    notenspiegel,
    statistik,
)

__all__ = [
    "bericht_markdown",
    "klassenbericht",
    "lade_ergebnisse",
    "notenspiegel",
    "statistik",
]
