"""ki – Datenschutz-bewusster Client für OpenAI-kompatible LLM-Server.

Unterstützt:
  - **LM Studio** (Standard, lokal auf ``http://localhost:1234``)
  - jeden weiteren OpenAI-kompatiblen Server (llama.cpp, vLLM, Ollama mit
    OpenAI-Endpunkt, GWDG, Hetzner, …)

Datenschutz-Garantien:
  - Daten gehen ausschließlich an den konfigurierten Endpunkt.
  - Bei ``endpunkt`` auf localhost verlassen keine Daten den Rechner.
  - Inhalte sollten VOR dem Versand durch ``pseudonymisiere_text`` geschickt
    werden: E-Mail-Muster und Klartext-IDs/-Namen werden entfernt.
  - Falls der Server nicht erreichbar ist, geben die Aufrufe ``None`` zurück
    (Aufrufer fällt auf regelbasierte Auswertung zurück – KEINE Daten „nach
    draußen").

Robuste Trick-Sammlung:
  - Thinking-Modelle zwingen, sofort JSON zu liefern (Assistant-Prefill)
  - Fallback-Cleanup von ``<think>…</think>``-Artefakten
  - ``<|channel|>…<|message|>``-Prefix abschneiden (gpt-oss)
  - Robustes JSON-Parsing (4-stufiger Fallback)
  - Bevorzugtes Modell explizit suchen statt ``models.data[0]``
"""

from __future__ import annotations

import json
import os
import platform
import re
import sys
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import Dict, List, Optional


# ─────────────────────────────────────────────────────────────
# Verfügbarkeit / Modellsuche
# ─────────────────────────────────────────────────────────────

def server_verfuegbar(endpunkt: str, timeout: float = 2.0) -> bool:
    """Pingt einen OpenAI-kompatiblen Server (``/v1/models``)."""
    url = f"{endpunkt.rstrip('/')}/v1/models"
    try:
        with urllib.request.urlopen(url, timeout=timeout) as r:
            return r.status == 200
    except (urllib.error.URLError, OSError, TimeoutError):
        return False


def liste_modelle(endpunkt: str, timeout: float = 5.0) -> List[str]:
    """Gibt die geladenen Modell-IDs zurück."""
    url = f"{endpunkt.rstrip('/')}/v1/models"
    try:
        with urllib.request.urlopen(url, timeout=timeout) as r:
            data = json.loads(r.read().decode("utf-8"))
            return [m.get("id", "") for m in data.get("data", []) if m.get("id")]
    except (urllib.error.URLError, OSError, TimeoutError, json.JSONDecodeError):
        return []


def waehle_modell(endpunkt: str, bevorzugt: Optional[str] = None,
                  timeout: float = 5.0) -> Optional[str]:
    """Sucht das passende Modell.

    ``models.data[0]`` ist nicht zwingend das konfigurierte Modell. Wenn
    ``bevorzugt`` angegeben, wird explizit per Substring (case-insensitive)
    gesucht. Fallback: erstes geladenes Modell.
    """
    models = liste_modelle(endpunkt, timeout)
    if not models:
        return None
    if bevorzugt:
        bev = bevorzugt.lower()
        for m in models:
            if m.lower() == bev:
                return m
        for m in models:
            if bev in m.lower() or m.lower() in bev:
                return m
    return models[0]


# ─────────────────────────────────────────────────────────────
# Pseudonymisierung VOR jedem Versand
# ─────────────────────────────────────────────────────────────

_EMAIL_RE = re.compile(r"\b[\w.+-]+@[\w.-]+\.\w{2,}\b")


def pseudonymisiere_text(text: str, klartext_ids: set) -> str:
    """Entfernt offensichtliche personenbezogene Daten aus einem Text.

    Sollte auf alles angewendet werden, was an die KI geht (Frage UND Antwort).
    ``klartext_ids``: bekannte Namen/IDs (z. B. aus dem Anonymisierungs-Mapping).
    """
    if not text:
        return text
    out = _EMAIL_RE.sub("[E-MAIL]", text)
    for kid in klartext_ids:
        if not kid:
            continue
        out = re.sub(re.escape(kid), "[SCHUELER]", out, flags=re.IGNORECASE)
        # Aus 'Max.Mustermann' wird auch 'Max Mustermann' erkannt
        teile = kid.replace(".", " ").split()
        if len(teile) >= 2:
            voller = " ".join(teile)
            out = re.sub(re.escape(voller), "[SCHUELER]", out, flags=re.IGNORECASE)
    return out


# ─────────────────────────────────────────────────────────────
# Modell-Fingerprints für Thinking-Behandlung
# ─────────────────────────────────────────────────────────────

_THINKING_PATTERNS = ("qwen3", "ministral", "magistral", "reasoning",
                      "-r1", "deepseek-r1")


def ist_thinking_modell(modell_id: str) -> bool:
    """Erkennt Modelle, die sonst lange Reasoning-Tokens produzieren."""
    m = (modell_id or "").lower()
    return any(p in m for p in _THINKING_PATTERNS)


# ─────────────────────────────────────────────────────────────
# Chat-Aufruf (OpenAI-kompatibel, mit/ohne SDK)
# ─────────────────────────────────────────────────────────────

def _baue_messages(prompt: str, system: Optional[str],
                   thinking_prefill: bool) -> List[Dict[str, str]]:
    msgs: List[Dict[str, str]] = []
    if system:
        msgs.append({"role": "system", "content": system})
    msgs.append({"role": "user", "content": prompt})
    if thinking_prefill:
        # Thinking-Modelle zwingen, sofort JSON zu liefern
        msgs.append({"role": "assistant", "content": "<think>\n\n</think>\n\n"})
    return msgs


def _chat_via_sdk(modell: str, messages: list, endpunkt: str,
                  api_key: str, timeout: float, temperature: float,
                  max_tokens: int, stream: bool = False) -> Optional[str]:
    try:
        import openai  # type: ignore
    except ImportError:
        return None
    try:
        client = openai.OpenAI(
            base_url=f"{endpunkt.rstrip('/')}/v1",
            api_key=api_key,
            timeout=timeout,
            max_retries=0,
        )
        resp = client.chat.completions.create(
            model=modell,
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
            stream=stream,
        )
        if stream:
            # Streaming entlastet Thinking-Modelle (kein Timeout beim langen
            # Prefill); Delta-Inhalte werden zusammengesetzt.
            teile: list[str] = []
            for chunk in resp:
                if chunk.choices and chunk.choices[0].delta.content:
                    teile.append(chunk.choices[0].delta.content)
            return "".join(teile)
        return resp.choices[0].message.content or ""
    except Exception:  # noqa: BLE001
        return None


def _chat_via_urllib(modell: str, messages: list, endpunkt: str,
                     api_key: str, timeout: float, temperature: float,
                     max_tokens: int) -> Optional[str]:
    url = f"{endpunkt.rstrip('/')}/v1/chat/completions"
    payload = {
        "model": modell,
        "messages": messages,
        "temperature": temperature,
        "max_tokens": max_tokens,
        "stream": False,
    }
    headers = {"Content-Type": "application/json"}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"
    try:
        req = urllib.request.Request(
            url, data=json.dumps(payload).encode("utf-8"),
            headers=headers, method="POST",
        )
        with urllib.request.urlopen(req, timeout=timeout) as r:
            data = json.loads(r.read().decode("utf-8"))
            return data["choices"][0]["message"]["content"]
    except (urllib.error.URLError, OSError, TimeoutError,
            json.JSONDecodeError, KeyError, IndexError):
        return None


def frage_llm(prompt: str,
              modell: Optional[str] = None,
              endpunkt: str = "http://localhost:1234",
              api_key: str = "lm-studio",
              system: Optional[str] = None,
              timeout: float = 300.0,
              temperature: float = 0.1,
              max_tokens: int = 1500,
              stream: bool = False) -> Optional[str]:
    """Sendet einen Chat-Aufruf an einen OpenAI-kompatiblen Server.

    Gibt den Text-Output zurück oder ``None`` bei Fehler/Unerreichbarkeit.
    Wenn ``modell`` ``None`` ist, wird das erste geladene Modell verwendet.
    ``stream=True`` nutzt SDK-Streaming (entlastet Thinking-Modelle).
    """
    if not server_verfuegbar(endpunkt, timeout=3.0):
        return None
    if modell is None:
        modell = waehle_modell(endpunkt)
        if not modell:
            return None

    thinking = ist_thinking_modell(modell)
    messages = _baue_messages(prompt, system, thinking_prefill=thinking)

    # Bevorzugt offizielles SDK; urllib-Fallback ohne `openai`-Paket
    # (urllib ohne Streaming).
    text = _chat_via_sdk(modell, messages, endpunkt, api_key,
                         timeout, temperature, max_tokens, stream=stream)
    if text is None:
        text = _chat_via_urllib(modell, messages, endpunkt, api_key,
                                timeout, temperature, max_tokens)
    return text


# ─────────────────────────────────────────────────────────────
# JSON-Robustheit (4-stufiger Fallback)
# ─────────────────────────────────────────────────────────────

def _bereinige_artefakte(text: str) -> str:
    """Entfernt typische LLM-Artefakte (Thinking-Tags, Channel-Marker)."""
    if not text:
        return text
    text = re.sub(r"<\|channel\|>[\s\S]*?<\|message\|>", "", text)
    text = re.sub(r"<think>[\s\S]*?</think>", "", text, flags=re.IGNORECASE)
    text = re.sub(r"<thinking>[\s\S]*?</thinking>", "", text, flags=re.IGNORECASE)
    return text.strip()


def extrahiere_json_robust(text: str) -> Optional[dict]:
    """4-stufiger Fallback:

    1. Direktes JSON-Parsing der gesamten Antwort.
    2. Markdown-Code-Blocks (``` json … ```) entfernen, dann parsen.
    3. Erstes geschweiftes ``{ … }`` per Regex extrahieren.
    4. Artefakte bereinigen und Schritt 1–3 wiederholen.
    """
    if not text:
        return None

    def _try(s: str) -> Optional[dict]:
        try:
            return json.loads(s)
        except (json.JSONDecodeError, ValueError):
            return None

    result = _try(text)
    if result is not None:
        return result

    no_codeblock = re.sub(r"```(?:json)?\s*", "", text, flags=re.IGNORECASE)
    no_codeblock = no_codeblock.replace("```", "").strip()
    result = _try(no_codeblock)
    if result is not None:
        return result

    m = re.search(r"\{[\s\S]*\}", no_codeblock)
    if m:
        result = _try(m.group(0))
        if result is not None:
            return result

    bereinigt = _bereinige_artefakte(text)
    if bereinigt != text:
        return extrahiere_json_robust(bereinigt)

    return None


# ─────────────────────────────────────────────────────────────
# Aufruf-Wrapper für Freitext-Bewertung
# ─────────────────────────────────────────────────────────────

_SYSTEM_PROMPT_BEWERTUNG = (
    "Du bewertest Schülerantworten fair und kurz. "
    "Antworte ausschließlich in gültigem JSON, ohne Markdown-Codeblöcke. "
    "Bewerte, ob die geforderten Aspekte in der Schülerantwort vorkommen. "
    "Sei tolerant bei Synonymen und Umformulierungen; bewerte streng nur bei "
    "fachlich falschen Aussagen. "
    "Diese Trennzeichen sind KEIN Inhalt, sondern Software-Marker: "
    "==== FRAGE ====, ==== ASPEKTE ====, ==== ANTWORT ===="
)


def bewerte_freitext(frage: str, erwartete_aspekte: list,
                     antwort: str,
                     modell: Optional[str] = None,
                     endpunkt: str = "http://localhost:1234",
                     api_key: str = "lm-studio",
                     klartext_ids: Optional[set] = None,
                     timeout: float = 300.0,
                     max_tokens: int = 1500) -> Optional[dict]:
    """Lässt ein LLM eine Freitext-Antwort einschätzen.

    Rückgabe::

        {"punkte": 0..1, "begruendung": str, "fehlend": [str]}

    Bei nicht erreichbarem Server oder unbrauchbarer Antwort: ``None``.
    """
    if not antwort or not antwort.strip():
        return {"punkte": 0.0,
                "begruendung": "Keine Antwort vorhanden.",
                "fehlend": list(erwartete_aspekte)}

    klartext_ids = klartext_ids or set()
    safe_antwort = pseudonymisiere_text(antwort, klartext_ids)
    safe_frage = pseudonymisiere_text(frage, klartext_ids)

    aspekte_text = "\n".join(f"- {a}" for a in erwartete_aspekte)
    prompt = (
        "==== FRAGE ====\n"
        f"{safe_frage}\n\n"
        "==== ASPEKTE ====\n"
        f"{aspekte_text}\n\n"
        "==== ANTWORT ====\n"
        f"{safe_antwort}\n\n"
        "Gib AUSSCHLIESSLICH ein JSON-Objekt mit folgenden Feldern zurück:\n"
        "{\n"
        '  "punkte": <Zahl von 0.0 bis 1.0>,\n'
        '  "begruendung": "<kurze Begründung in einem Satz>",\n'
        '  "fehlend": ["<fehlender Aspekt>", ...]\n'
        "}"
    )

    text = frage_llm(prompt, modell=modell, endpunkt=endpunkt,
                     api_key=api_key, system=_SYSTEM_PROMPT_BEWERTUNG,
                     timeout=timeout, max_tokens=max_tokens)
    if not text:
        return None

    data = extrahiere_json_robust(text)
    if not data:
        return None

    punkte = data.get("punkte", 0)
    try:
        punkte = float(punkte)
    except (TypeError, ValueError):
        punkte = 0.0
    punkte = max(0.0, min(1.0, punkte))
    return {
        "punkte": punkte,
        "begruendung": str(data.get("begruendung", ""))[:400],
        "fehlend": list(data.get("fehlend", []))[:10],
    }


# ─────────────────────────────────────────────────────────────
# Multi-Provider-Konfiguration (lokal / Hetzner / GWDG …)
# ─────────────────────────────────────────────────────────────
#
# DATENSCHUTZ:
#   "lokal"   – Daten verlassen den Rechner nicht (LM Studio).
#   "hetzner" – Serverstandort Deutschland, DSGVO-konform, AV-Vertrag möglich.
#   "gwdg"    – Akademische Cloud (GWDG), Serverstandort DE.
# API-Keys werden NIE hart codiert, sondern aus Umgebungsvariablen gelesen
# (``api_key_env``); ``api_key_default`` greift nur für lokale Server.

# Hardware-abhängige lokale Defaults: Apple Silicon (Unified Memory, GPU) ist
# deutlich schneller als RPi/generische CPU mit Thinking-Modellen.
_APPLE_SILICON = sys.platform == "darwin" and platform.machine() == "arm64"
_LOKAL_TIMEOUT = 600.0 if _APPLE_SILICON else 3600.0
_LOKAL_BATCH = 1


@dataclass
class ProviderConfig:
    """Konfiguration eines OpenAI-kompatiblen KI-Providers.

    ``base_url`` ist die Host-Basis OHNE ``/v1`` (passend zu ``frage_llm``'s
    ``endpunkt``-Konvention); ``api_base`` liefert die Variante MIT ``/v1`` für
    Code, der direkt ``OpenAI(base_url=…)`` nutzt. ``model`` = "auto" → Modell am
    Server automatisch wählen. Der API-Key kommt aus ``api_key_env``.
    """
    name: str
    beschreibung: str
    base_url: str
    api_key_env: str = ""
    api_key_default: str = "lm-studio"
    model: str = "auto"
    is_lokal: bool = False
    timeout: float = 300.0
    batch_groesse: int = 4    # Kriterien pro Batch (Cloud i. d. R. größer)
    # Art des Servers: "lmstudio" (Modelle per `lms`-CLI ladbar),
    # "ollama" (lädt Modelle bei Bedarf selbst, Kontext über OLLAMA_CONTEXT_LENGTH),
    # "openai" (beliebiger OpenAI-kompatibler Server, z. B. llama-server/MLX).
    server: str = "openai"
    # Optionale Umgebungsvariable, die ``base_url`` überschreibt (Host OHNE /v1).
    base_url_env: str = ""

    def basis_url(self) -> str:
        """``base_url``, ggf. aus ``base_url_env`` überschrieben (ohne ``/v1``)."""
        wert = os.environ.get(self.base_url_env, "").strip() if self.base_url_env else ""
        if wert:
            wert = wert.rstrip("/")
            return wert[:-3] if wert.endswith("/v1") else wert
        return self.base_url

    def api_key(self) -> str:
        if self.api_key_env:
            wert = os.environ.get(self.api_key_env, "")
            if wert:
                return wert
        return self.api_key_default

    @property
    def api_base(self) -> str:
        """Basis-URL inkl. ``/v1`` (für direkten ``OpenAI(base_url=…)``-Gebrauch)."""
        return self.basis_url().rstrip("/") + "/v1"


PROVIDER: Dict[str, ProviderConfig] = {
    "lokal": ProviderConfig(
        name="LM Studio (lokal)",
        beschreibung="Lokales LLM via LM Studio – Daten verlassen den Rechner nicht.",
        base_url="http://localhost:1234",
        api_key_env="LMSTUDIO_API_KEY",
        api_key_default="lm-studio",
        model="auto",
        is_lokal=True,
        timeout=_LOKAL_TIMEOUT,
        batch_groesse=_LOKAL_BATCH,
        server="lmstudio",
        base_url_env="LMSTUDIO_BASE_URL",
    ),
    "ollama": ProviderConfig(
        name="Ollama (lokal)",
        beschreibung="Lokales LLM via Ollama – Daten verlassen den Rechner nicht. "
                     "Kontext vor dem Start setzen: OLLAMA_CONTEXT_LENGTH=32768.",
        base_url="http://localhost:11434",
        api_key_env="OLLAMA_API_KEY",
        api_key_default="ollama",
        model="auto",
        is_lokal=True,
        timeout=_LOKAL_TIMEOUT,
        batch_groesse=_LOKAL_BATCH,
        server="ollama",
        base_url_env="OLLAMA_BASE_URL",
    ),
    "bonsai": ProviderConfig(
        name="Bonsai (lokal)",
        beschreibung="Lokaler OpenAI-kompatibler Server der Bonsai-Laufzeit – "
                     "Daten verlassen den Rechner nicht. Adresse über BONSAI_BASE_URL.",
        base_url="http://localhost:8080",
        api_key_env="BONSAI_API_KEY",
        api_key_default="bonsai",
        model="auto",
        is_lokal=True,
        timeout=_LOKAL_TIMEOUT,
        batch_groesse=_LOKAL_BATCH,
        server="openai",
        base_url_env="BONSAI_BASE_URL",
    ),
    "hetzner": ProviderConfig(
        name="Hetzner AI Inference",
        beschreibung="DSGVO-konform, Serverstandort Deutschland. "
                     "API-Key: https://console.hetzner.cloud → API-Tokens",
        base_url="https://inference.de1.hetzner.ai",
        api_key_env="HETZNER_AI_API_KEY",
        api_key_default="",
        model="mistral-small-latest",
        timeout=300.0,
    ),
    "gwdg": ProviderConfig(
        name="GWDG Akademische Cloud",
        beschreibung="GWDG Chat-AI API, Serverstandort Deutschland. "
                     "Zugang über DFN-AAI / GWDG-Account. "
                     "API-Key: https://chat.gwdg.de → API-Schlüssel",
        base_url="https://chat.gwdg.de/api",
        api_key_env="GWDG_API_KEY",
        api_key_default="",
        model="meta-llama-3.1-70b-instruct",
        timeout=300.0,
    ),
}


def provider_konfig(name: str) -> ProviderConfig:
    """Liefert die ProviderConfig zu einem Namen (z. B. 'lokal', 'hetzner', 'gwdg')."""
    try:
        return PROVIDER[name.lower()]
    except KeyError:
        raise KeyError(
            f"Unbekannter Provider '{name}'. Verfügbar: {', '.join(PROVIDER)}"
        ) from None


def verfuegbare_provider() -> Dict[str, str]:
    """Mapping {name: beschreibung} aller bekannten Provider."""
    return {k: v.beschreibung for k, v in PROVIDER.items()}


def frage_llm_provider(prompt: str,
                       provider: "str | ProviderConfig" = "lokal",
                       modell: Optional[str] = None,
                       system: Optional[str] = None,
                       temperature: float = 0.1,
                       max_tokens: int = 1500,
                       stream: bool = False) -> Optional[str]:
    """Wie ``frage_llm``, aber über eine Provider-Konfiguration.

    ``provider`` ist ein Name ('lokal'/'hetzner'/'gwdg') oder eine
    ``ProviderConfig``. ``modell`` überschreibt das Provider-Modell.
    """
    cfg = provider if isinstance(provider, ProviderConfig) else provider_konfig(provider)
    gewaehlt = modell or (None if cfg.model in ("", "auto") else cfg.model)
    return frage_llm(
        prompt,
        modell=gewaehlt,
        endpunkt=cfg.basis_url(),
        api_key=cfg.api_key(),
        system=system,
        timeout=cfg.timeout,
        temperature=temperature,
        max_tokens=max_tokens,
        stream=stream,
    )
