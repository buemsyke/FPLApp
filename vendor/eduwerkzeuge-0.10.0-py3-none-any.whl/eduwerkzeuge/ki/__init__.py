"""ki – datenschutz-bewusster Client für OpenAI-kompatible LLM-Server.

Beispiel:
    from eduwerkzeuge.ki import frage_llm, bewerte_freitext, pseudonymisiere_text

    # Vor dem Versand pseudonymisieren:
    sicher = pseudonymisiere_text(text, klartext_ids={"Max Mustermann"})
    antwort = frage_llm(sicher, endpunkt="http://localhost:1234")

    # Freitext-Aufgabe bewerten lassen (gibt None, wenn Server offline):
    erg = bewerte_freitext(frage, ["Aspekt A", "Aspekt B"], antwort,
                           klartext_ids={"Max Mustermann"})
"""

from .core import (
    PROVIDER,
    ProviderConfig,
    bewerte_freitext,
    extrahiere_json_robust,
    frage_llm,
    frage_llm_provider,
    ist_thinking_modell,
    liste_modelle,
    provider_konfig,
    pseudonymisiere_text,
    server_verfuegbar,
    verfuegbare_provider,
    waehle_modell,
)

__all__ = [
    "PROVIDER",
    "ProviderConfig",
    "bewerte_freitext",
    "extrahiere_json_robust",
    "frage_llm",
    "frage_llm_provider",
    "ist_thinking_modell",
    "liste_modelle",
    "provider_konfig",
    "pseudonymisiere_text",
    "server_verfuegbar",
    "verfuegbare_provider",
    "waehle_modell",
]
