#!/usr/bin/env python3
"""CLI/Diagnose für den LLM-Client: ``edu-ki``.

  edu-ki --modelle                 # geladene Modelle am Endpunkt auflisten
  edu-ki "Was ist eine Tabelle?"   # einen Prompt senden
  edu-ki --endpunkt http://host:1234 --modell qwen "…"

Standard-Endpunkt: http://localhost:1234 (LM Studio).
"""

import argparse
import sys

from .core import frage_llm, liste_modelle, server_verfuegbar, waehle_modell


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        prog="edu-ki",
        description="Diagnose/Aufruf eines OpenAI-kompatiblen LLM-Servers (z. B. LM Studio).",
    )
    p.add_argument("prompt", nargs="?", help="Prompt-Text (weglassen für --modelle).")
    p.add_argument("--endpunkt", default="http://localhost:1234", help="Server-Basis-URL.")
    p.add_argument("--api-key", default="lm-studio", help="API-Key (lokal beliebig).")
    p.add_argument("--modell", default=None, help="Bevorzugtes Modell (Substring genügt).")
    p.add_argument("--modelle", action="store_true", help="Nur geladene Modelle auflisten.")
    p.add_argument("--system", default=None, help="Optionaler System-Prompt.")
    args = p.parse_args(argv)

    if not server_verfuegbar(args.endpunkt, timeout=3.0):
        print(f"Server nicht erreichbar: {args.endpunkt}", file=sys.stderr)
        return 1

    if args.modelle or not args.prompt:
        modelle = liste_modelle(args.endpunkt)
        if not modelle:
            print("Keine Modelle geladen.", file=sys.stderr)
            return 1
        print(f"Geladene Modelle an {args.endpunkt}:")
        for m in modelle:
            print(f"  - {m}")
        return 0

    modell = waehle_modell(args.endpunkt, bevorzugt=args.modell)
    antwort = frage_llm(args.prompt, modell=modell, endpunkt=args.endpunkt,
                        api_key=args.api_key, system=args.system)
    if antwort is None:
        print("Keine Antwort (Server-/Modellfehler).", file=sys.stderr)
        return 1
    print(antwort)
    return 0


if __name__ == "__main__":
    sys.exit(main())
