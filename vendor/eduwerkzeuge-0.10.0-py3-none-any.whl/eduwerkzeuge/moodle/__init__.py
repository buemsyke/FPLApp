"""moodle – Bausteine für Moodle-Abgaben.

Ordnernamen parsen, Abgabe-ZIPs auswerten, Schülerlisten gewinnen. Diese
Primitive werden von ``anonymisierung`` genutzt und stehen auch Korrektur-/
Auswertungs-Skripten zur Verfügung.

Beispiel:
    from eduwerkzeuge.moodle import parse_moodle_ordnername, studenten_aus_zip
    parse_moodle_ordnername("Max Mustermann_123_assignsubmission_file_")  # "Max Mustermann"
"""

from .core import (
    aufgaben_name_aus_zip,
    bestimme_schueler_tiefe,
    finde_csv,
    ist_moodle_ordner,
    lade_schueler_aus_csv,
    normalisiere_umlaute,
    parse_moodle_ordnername,
    schueler_aus_zips,
    strings_aus_zips,
    studenten_aus_zip,
)

__all__ = [
    "aufgaben_name_aus_zip",
    "bestimme_schueler_tiefe",
    "finde_csv",
    "ist_moodle_ordner",
    "lade_schueler_aus_csv",
    "normalisiere_umlaute",
    "parse_moodle_ordnername",
    "schueler_aus_zips",
    "strings_aus_zips",
    "studenten_aus_zip",
]
