#!/usr/bin/env python3
"""
moodle – Bausteine für Moodle-Abgaben (Ordnernamen, ZIPs, Schülerlisten)
========================================================================

Diese kleinen, stabilen Primitive lagen bisher in ``anonymisierung`` und wurden
in mehreren Korrektur-/Auswertungs-Skripten nachgebaut. Sie leben jetzt zentral
hier; ``anonymisierung`` greift darauf zurück.

Enthalten:
  * ``parse_moodle_ordnername`` / ``ist_moodle_ordner`` – Schülername aus einem
    Moodle-Abgabe-Ordner gewinnen bzw. erkennen.
  * ``normalisiere_umlaute`` – Umlaut-Transliteration wie Moodle sie in
    Nutzernamen vornimmt (ä→ae …).
  * ``aufgaben_name_aus_zip`` / ``bestimme_schueler_tiefe`` – Aufgabenname und
    Verzeichnistiefe einer Abgabe-ZIP bestimmen.
  * ``schueler_aus_zips`` / ``studenten_aus_zip`` / ``strings_aus_zips`` –
    Schülernamen bzw. alle Pfadbestandteile aus ZIP-Abgaben sammeln.
  * ``finde_csv`` / ``lade_schueler_aus_csv`` – die Ergebnisse-CSV finden/lesen.

Beispiel:
    from eduwerkzeuge.moodle import parse_moodle_ordnername, studenten_aus_zip
    parse_moodle_ordnername("Arne Lucas_624509814_assignsubmission_file_")  # "Arne Lucas"
    studenten_aus_zip(Path("abgaben.zip"))                                  # ["Arne Lucas", ...]
"""

from __future__ import annotations

import csv
import re
import zipfile
from pathlib import Path


# ============================================================
# Namens-Hilfsfunktionen
# ============================================================

def normalisiere_umlaute(text: str) -> str:
    """Ersetzt Umlaute/ß durch ASCII-Äquivalente (wie Moodle es tut)."""
    return (
        text
        .replace("ä", "ae").replace("Ä", "Ae")
        .replace("ö", "oe").replace("Ö", "Oe")
        .replace("ü", "ue").replace("Ü", "Ue")
        .replace("ß", "ss").replace("ẞ", "Ss")
    )


def parse_moodle_ordnername(ordnername: str) -> str:
    """Extrahiert den Schülernamen aus einem Moodle-Ordnernamen.

    Unterstützt u. a.:
      "Arne Lucas (Arne.Lucas@bbs-syke.schule)"
      "Claas Winte (…)_group_6020383"
      "Arne Lucas_624509814_assignsubmission_file_"
      "Max_Mustermann", "MaxMustermann", "Max Mustermann - Kopie", "… (1)"
    """
    name = ordnername.strip()
    name = re.sub(r"_group_\d+$", "", name).strip()
    name = re.sub(r"\s*\([^)]*@[^)]*\)\s*$", "", name).strip()
    name = re.sub(r"_\d+_assignsubmission_file_?$", "", name).strip()
    name = re.sub(r"\s*-\s*Kopie\s*\(\d+\)\s*$", "", name, flags=re.IGNORECASE).strip()
    name = re.sub(r"\s*\(\d+\)\s*$", "", name).strip()
    name = re.sub(r"\s+-\s+Kopie\s*$", "", name, flags=re.IGNORECASE).strip()
    if "_" in name and not any(c.isdigit() for c in name.split("_")):
        name = name.replace("_", " ")
    return name


def ist_moodle_ordner(ordnername: str) -> bool:
    """True, wenn der Ordnername eindeutig nach Moodle-Abgabe aussieht."""
    return bool(
        re.search(r"\([^)]*@[^)]*\)", ordnername)
        or re.search(r"_group_\d+", ordnername)
        or re.search(r"_\d+_assignsubmission_file", ordnername)
    )


# ============================================================
# Ergebnisse-CSV
# ============================================================

def finde_csv(basis: Path) -> Path | None:
    """Sucht die Ergebnisse-CSV ab ``basis`` aufwärts (max. 4 Ebenen)."""
    for verz in [basis] + list(basis.parents)[:4]:
        for kandidat in [verz / "ergebnisse.csv", verz / "Ergebnisse" / "ergebnisse.csv"]:
            if kandidat.exists():
                return kandidat
    return None


def lade_schueler_aus_csv(csv_pfad: Path) -> list[str]:
    """Gibt eine Liste aller Schüler-Vollnamen aus der Ergebnisse-CSV zurück."""
    with open(csv_pfad, encoding="utf-8") as fh:
        reader = csv.DictReader(fh, delimiter=";")
        return [z["Schüler"].strip() for z in reader if z.get("Schüler", "").strip()]


# ============================================================
# Abgabe-ZIPs
# ============================================================

def bestimme_schueler_tiefe(zf: zipfile.ZipFile) -> int:
    """Verzeichnisebene, auf der die Schüler-Ordner liegen (0 oder 1)."""
    dateien = [info for info in zf.infolist() if not info.is_dir()]
    if not dateien:
        return 0
    top_dirs = {Path(i.filename).parts[0] for i in dateien if Path(i.filename).parts}
    return 1 if len(top_dirs) == 1 else 0


def aufgaben_name_aus_zip(zip_pfad: Path) -> str:
    """Bestimmt den Aufgabennamen einer Abgabe-ZIP (Top-Ordner bzw. Dateiname)."""
    try:
        with zipfile.ZipFile(zip_pfad, "r") as zf:
            if bestimme_schueler_tiefe(zf) == 1:
                top_dirs = {
                    Path(i.filename).parts[0]
                    for i in zf.infolist() if not i.is_dir() and Path(i.filename).parts
                }
                if len(top_dirs) == 1:
                    return next(iter(top_dirs))
    except Exception:
        pass
    name = zip_pfad.stem
    name = re.sub(r"^assignment-", "", name)
    name = re.sub(r"\s+\(.*$", "", name)
    name = re.sub(r"-\d{2}\.\d{2}\.\d{4}.*$", "", name)
    name = re.sub(r"(?<!\w\d)_(?!\d)", " ", name)
    return name.strip()


def schueler_aus_zips(zip_dateien: list[Path]) -> list[str]:
    """Sammelt die Schüler-Vollnamen aus einer Liste von Abgabe-ZIPs."""
    namen: set[str] = set()
    for zip_pfad in zip_dateien:
        try:
            with zipfile.ZipFile(zip_pfad, "r") as zf:
                tiefe = bestimme_schueler_tiefe(zf)
                for info in zf.infolist():
                    if info.is_dir():
                        continue
                    teile = Path(info.filename).parts
                    if len(teile) >= tiefe + 2:
                        name = parse_moodle_ordnername(teile[tiefe])
                        if name:
                            namen.add(name)
        except Exception:
            pass
    return sorted(namen, key=str.casefold)


def studenten_aus_zip(zip_pfad: Path) -> list[str]:
    """Schüler-Vollnamen aus einer einzelnen Abgabe-ZIP."""
    return schueler_aus_zips([Path(zip_pfad)])


def strings_aus_zips(zip_dateien: list[Path]) -> set[str]:
    """Alle Ordner-/Pfadbestandteile aus ZIPs (z. B. für Domain-Erkennung)."""
    s: set[str] = set()
    for zp in zip_dateien:
        try:
            with zipfile.ZipFile(zp, "r") as zf:
                for info in zf.infolist():
                    s.update(Path(info.filename).parts)
        except Exception:
            pass
    return s
