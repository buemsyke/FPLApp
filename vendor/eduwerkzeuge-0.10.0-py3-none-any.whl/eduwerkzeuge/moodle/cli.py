#!/usr/bin/env python3
"""CLI für Moodle-Abgaben: ``edu-moodle``.

  edu-moodle info abgaben.zip        # Aufgabenname + Anzahl erkannter Abgaben (ohne Namen)
  edu-moodle info ./Abgaben          # alle *.zip im Ordner auswerten
  edu-moodle info abgaben.zip --namen   # zusätzlich Namen anzeigen (nur lokal!)
  edu-moodle name "Max Mustermann_12345_assignsubmission_file_"   # Ordnername → Name
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from .core import (
    aufgaben_name_aus_zip,
    parse_moodle_ordnername,
    studenten_aus_zip,
)


def _zip_liste(ziel: Path) -> list[Path]:
    if ziel.is_file() and ziel.suffix.lower() == ".zip":
        return [ziel]
    if ziel.is_dir():
        return sorted(ziel.glob("*.zip"))
    return []


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        prog="edu-moodle",
        description="Moodle-Abgaben auswerten (Aufgabe/Schüler aus ZIPs, Ordnernamen parsen).",
    )
    sub = p.add_subparsers(dest="cmd", required=True)

    pi = sub.add_parser("info", help="Aufgabe + Schüler aus ZIP(s) auflisten")
    pi.add_argument("ziel", help="ZIP-Datei oder Ordner mit *.zip")
    pi.add_argument("--namen", action="store_true",
                    help="Namen der Abgebenden anzeigen (nur lokal; Standard: nur Anzahl).")
    pi.add_argument("--nur-anzahl", action="store_true",
                    help="(Standard seit 0.2.0, aus Kompatibilitätsgründen weiter akzeptiert)")

    pn = sub.add_parser("name", help="Schülername aus einem Moodle-Ordnernamen")
    pn.add_argument("ordnername", help="z. B. 'Max Mustermann_123_assignsubmission_file_'")

    args = p.parse_args(argv)

    if args.cmd == "name":
        print(parse_moodle_ordnername(args.ordnername))
        return 0

    if args.cmd == "info":
        ziel = Path(args.ziel)
        zips = _zip_liste(ziel)
        if not zips:
            print(f"Keine ZIP-Datei(en) gefunden unter: {ziel}", file=sys.stderr)
            return 1
        for z in zips:
            schueler = studenten_aus_zip(z)
            print(f"{z.name}")
            print(f"  Aufgabe : {aufgaben_name_aus_zip(z)}")
            if args.namen and not args.nur_anzahl:
                print(f"  Schüler ({len(schueler)}): {', '.join(schueler) if schueler else '–'}")
            else:
                print(f"  Abgaben : {len(schueler)}  (Namen mit --namen, nur lokal)")
        return 0

    return 1


if __name__ == "__main__":
    sys.exit(main())
