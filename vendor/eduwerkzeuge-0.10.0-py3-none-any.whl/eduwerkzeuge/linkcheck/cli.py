#!/usr/bin/env python3
"""CLI für den externen Linkcheck: ``edu-linkcheck``.

  edu-linkcheck                       # aktuelles Verzeichnis, Standardordner
  edu-linkcheck /pfad/zum/projekt
  edu-linkcheck --student-site        # zusätzlich _student_site/docs prüfen
  edu-linkcheck --refresh             # Cache ignorieren, alle Links neu prüfen

Prüft nur externe http(s)-Links in Markdown-Dateien unter lessons/,
solutions/, h5p/ (optional _student_site/docs/). Interne/relative Links
prüft mkdocs --strict bereits. Exitcode 1, wenn tote oder auffällige
Links gefunden wurden (siehe Bericht) – ein rein lokales Werkzeug, kein
CI-Gate.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from .core import (
    STANDARD_CACHE_NAME,
    STANDARD_ORDNER,
    pruefe_projekt,
    formatiere_bericht,
    standard_regeln_datei,
)


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        prog="edu-linkcheck",
        description="Externe (http/https) Links in Unterrichtsmaterialien prüfen.",
    )
    p.add_argument("projekt", nargs="?", default=".", help="Projektverzeichnis (Default: aktuelles Verzeichnis).")
    p.add_argument("--pfade", nargs="+", default=None,
                    help=f"Zu durchsuchende Unterordner (Default: {' '.join(STANDARD_ORDNER)}).")
    p.add_argument("--student-site", action="store_true",
                    help="zusätzlich _student_site/docs durchsuchen.")
    p.add_argument("--timeout", type=float, default=10.0, help="Timeout je Link in Sekunden (Default 10).")
    p.add_argument("--worker", type=int, default=8, help="Maximale gleichzeitige Prüfungen (Default 8).")
    p.add_argument("--cache-datei", default=None,
                    help=f"Cache-Datei (Default: <projekt>/{STANDARD_CACHE_NAME}).")
    p.add_argument("--cache-max-alter", type=float, default=24.0,
                    help="Cache-Höchstalter in Stunden (Default 24; 0 = immer neu prüfen).")
    p.add_argument("--refresh", action="store_true",
                    help="Cache ignorieren und alle Links neu prüfen.")
    p.add_argument("--ignore-datei", default=None,
                    help="Ignorier-/Erwartungsliste (Default: <projekt>/scripts/linkcheck_ignore.yaml).")
    args = p.parse_args(argv)

    projekt = Path(args.projekt).resolve()
    if not projekt.is_dir():
        print(f"Kein Verzeichnis: {projekt}", file=sys.stderr)
        return 2

    ordner = tuple(args.pfade) if args.pfade else STANDARD_ORDNER
    regeln_datei = Path(args.ignore_datei) if args.ignore_datei else standard_regeln_datei(projekt)
    cache_datei = Path(args.cache_datei) if args.cache_datei else projekt / STANDARD_CACHE_NAME

    eintraege = pruefe_projekt(
        projekt,
        ordner=ordner,
        student_site=args.student_site,
        timeout=args.timeout,
        worker=args.worker,
        cache_datei=cache_datei,
        cache_max_alter=args.cache_max_alter,
        cache_erzwingen=args.refresh,
        regeln_datei=regeln_datei,
    )

    if not eintraege:
        print("Keine externen Links gefunden.")
        return 0

    print(formatiere_bericht(eintraege))
    return 1 if any(e.problematisch for e in eintraege) else 0


if __name__ == "__main__":
    sys.exit(main())
