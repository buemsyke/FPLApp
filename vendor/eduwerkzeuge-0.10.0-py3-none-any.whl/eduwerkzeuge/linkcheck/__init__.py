"""linkcheck – externe (http/https) Links in Unterrichtsmaterialien prüfen.

Durchsucht ein Projekt (Standard: ``lessons/``, ``solutions/``, ``h5p/``) nach
Markdown-Dateien, prüft jeden gefundenen ``http(s)``-Link genau einmal und
berichtet Statuscode, Fundstelle(n) und Seitentitel. Interne/relative Links
prüft mkdocs --strict bereits, dafür ist dieses Modul nicht zuständig.

Beispiel:
    from eduwerkzeuge.linkcheck import pruefe_projekt, formatiere_bericht
    eintraege = pruefe_projekt(Path("."))
    print(formatiere_bericht(eintraege))
"""

from .core import (
    Fundstelle,
    LinkEintrag,
    LinkPruefung,
    Regel,
    STANDARD_CACHE_NAME,
    STANDARD_ORDNER,
    STUDENT_SITE_ORDNER,
    extrahiere_links_aus_text,
    finde_markdown_dateien,
    formatiere_bericht,
    lade_cache,
    lade_regeln,
    pruefe_link,
    pruefe_projekt,
    sammle_links,
    speichere_cache,
    standard_regeln_datei,
)

__all__ = [
    "Fundstelle",
    "LinkEintrag",
    "LinkPruefung",
    "Regel",
    "STANDARD_CACHE_NAME",
    "STANDARD_ORDNER",
    "STUDENT_SITE_ORDNER",
    "extrahiere_links_aus_text",
    "finde_markdown_dateien",
    "formatiere_bericht",
    "lade_cache",
    "lade_regeln",
    "pruefe_link",
    "pruefe_projekt",
    "sammle_links",
    "speichere_cache",
    "standard_regeln_datei",
]
