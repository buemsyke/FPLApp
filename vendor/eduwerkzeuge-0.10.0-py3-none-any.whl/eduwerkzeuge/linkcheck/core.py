"""linkcheck – externe (http/https) Links in Markdown-Materialien prüfen.

Durchsucht ein Projektverzeichnis (Standard: ``lessons/``, ``solutions/``,
``h5p/``) nach ``.md``-Dateien, sammelt alle ``http(s)``-Links (Markdown-Links
UND nackte URLs, auch in Tabellen/eingerückten Blöcken) und prüft jeden
einmalig per HTTP-Anfrage. Interne/relative Links werden nicht geprüft – das
übernimmt ``mkdocs --strict``.

Geht ins Netz – siehe KI-REFERENZ.md §3 Ressourcen-Profil (wie ``ki``, aber
ohne LLM-Server: nur die geprüften Ziel-URLs selbst).
"""

from __future__ import annotations

import json
import re
import time
import urllib.error
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from pathlib import Path
from urllib.parse import urlsplit

import yaml

STANDARD_ORDNER = ("lessons", "solutions", "h5p")
STUDENT_SITE_ORDNER = ("_student_site/docs",)
STANDARD_CACHE_NAME = ".linkcheck-cache.json"

USER_AGENT = "eduwerkzeuge-linkcheck/1.0 (lokales Unterrichtswerkzeug; kein Crawler)"
MAX_LESEBYTES = 65536  # genug für <title> im <head>, spart Bandbreite bei großen Seiten

_LINK_MD_RE = re.compile(r'\[[^\]]*\]\((https?://[^\s)]+)(?:\s+"[^"]*")?\)')
_URL_RE = re.compile(r'https?://[^\s<>\[\]"\'()`]+')
_SATZZEICHEN_ENDE = '.,;:!?)"\'`”“»›'
_TITLE_RE = re.compile(r'<title[^>]*>(.*?)</title>', re.IGNORECASE | re.DOTALL)


# ─────────────────────────────────────────────────────────────
# Datenmodell
# ─────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class Fundstelle:
    datei: Path
    zeile: int

    def __str__(self) -> str:
        return f"{self.datei}:{self.zeile}"


@dataclass
class LinkPruefung:
    """Ergebnis einer einzelnen HTTP-Prüfung (bzw. aus dem Cache geladen)."""
    url: str
    status_code: int | None = None
    titel: str | None = None
    fehler: str | None = None          # Verbindungsfehler-Text; None wenn eine HTTP-Antwort kam
    weitergeleitet_nach: str | None = None
    geprueft_am: float = 0.0

    @property
    def tot(self) -> bool:
        if self.fehler is not None:
            return True
        return self.status_code is not None and self.status_code >= 400


@dataclass
class Regel:
    """Eine Zeile aus der projektspezifischen Ignorier-/Erwartungsliste."""
    url: str
    ignorieren: bool = False
    erwarteter_text: str = ""
    grund: str = ""


@dataclass
class LinkEintrag:
    """Ein geprüfter Link mit allen Fundstellen im Projekt."""
    url: str
    fundstellen: list[Fundstelle] = field(default_factory=list)
    pruefung: LinkPruefung | None = None
    ignoriert: bool = False
    ignoriert_grund: str = ""
    erwarteter_text: str = ""

    @property
    def text_abweichend(self) -> bool:
        """True, wenn ein erwarteter Text/Titel hinterlegt ist, aber im aktuellen
        Titel nicht mehr vorkommt (z. B. geparkte Domain, Inhaltswechsel)."""
        if not self.erwarteter_text or self.pruefung is None or self.pruefung.tot:
            return False
        return self.erwarteter_text.lower() not in (self.pruefung.titel or "").lower()

    @property
    def problematisch(self) -> bool:
        """True, wenn der Link im Bericht als Fehlschlag zählen soll (Exit-Code)."""
        if self.ignoriert or self.pruefung is None:
            return False
        return self.pruefung.tot or self.text_abweichend


# ─────────────────────────────────────────────────────────────
# Link-Extraktion aus Markdown
# ─────────────────────────────────────────────────────────────

def finde_markdown_dateien(projekt: Path, ordner: tuple[str, ...] = STANDARD_ORDNER) -> list[Path]:
    """Alle ``*.md``-Dateien unter den angegebenen Unterordnern (rekursiv, sortiert)."""
    dateien: list[Path] = []
    for name in ordner:
        basis = projekt / name
        if basis.is_dir():
            dateien.extend(sorted(basis.rglob("*.md")))
    return dateien


def _saeubere_url(url: str) -> str:
    """Schneidet Satzzeichen ab, die zum umgebenden Text gehören, nicht zur URL."""
    return url.rstrip(_SATZZEICHEN_ENDE)


def extrahiere_links_aus_text(text: str) -> list[tuple[str, int]]:
    """Gibt (url, zeilennummer) für jeden http(s)-Link einer Markdown-Datei zurück.

    Erfasst Markdown-Links ``[text](url)``, nackte URLs (auch in Inline-Code
    `` `url` `` und Zitaten ``> …``) sowie beides in Tabellenzeilen und
    eingerückten Blöcken (Einrückung ändert an zeilenweiser Regex nichts).
    """
    treffer: list[tuple[str, int]] = []
    for i, zeile in enumerate(text.splitlines(), start=1):
        belegt: list[tuple[int, int]] = []
        for m in _LINK_MD_RE.finditer(zeile):
            treffer.append((_saeubere_url(m.group(1)), i))
            belegt.append(m.span(1))
        for m in _URL_RE.finditer(zeile):
            if any(a <= m.start() < b for a, b in belegt):
                continue  # bereits als Markdown-Link erfasst
            treffer.append((_saeubere_url(m.group(0)), i))
    return treffer


def sammle_links(dateien: list[Path], projekt: Path) -> dict[str, list[Fundstelle]]:
    """Liest alle Dateien ein und gruppiert die Fundstellen je eindeutiger URL."""
    gesammelt: dict[str, list[Fundstelle]] = {}
    for datei in dateien:
        text = datei.read_text(encoding="utf-8")
        rel = datei.relative_to(projekt) if datei.is_absolute() else datei
        for url, zeile in extrahiere_links_aus_text(text):
            gesammelt.setdefault(url, []).append(Fundstelle(rel, zeile))
    return gesammelt


# ─────────────────────────────────────────────────────────────
# Ignorier-/Erwartungsliste (Konfigdatei im Projekt, nicht in der Bibliothek)
# ─────────────────────────────────────────────────────────────

def standard_regeln_datei(projekt: Path) -> Path:
    return projekt / "scripts" / "linkcheck_ignore.yaml"


def lade_regeln(pfad: Path) -> dict[str, Regel]:
    """Lädt die projektspezifische Liste; leer, wenn die Datei fehlt.

    Format:
        links:
          - url: "https://3v4l.org/xxxxx"
            ignorieren: true
            grund: "Platzhalter in Musteraufgabe für eine Fehlermeldung"
          - url: "https://phptutor.com"
            erwarteter_text: "Lerntool"
            grund: "Domain wechselte einmal den Inhaber"
    """
    if not pfad.is_file():
        return {}
    daten = yaml.safe_load(pfad.read_text(encoding="utf-8")) or {}
    regeln: dict[str, Regel] = {}
    for eintrag in daten.get("links", []) or []:
        url = str(eintrag.get("url", "")).strip()
        if not url:
            continue
        regeln[url] = Regel(
            url=url,
            ignorieren=bool(eintrag.get("ignorieren", False)),
            erwarteter_text=re.sub(r"\s+", " ", str(eintrag.get("erwarteter_text", "") or "")).strip(),
            grund=re.sub(r"\s+", " ", str(eintrag.get("grund", "") or "")).strip(),
        )
    return regeln


# ─────────────────────────────────────────────────────────────
# HTTP-Prüfung
# ─────────────────────────────────────────────────────────────

def _extrahiere_titel(rohtext: bytes) -> str | None:
    if not rohtext:
        return None
    text = rohtext.decode("utf-8", errors="replace")
    m = _TITLE_RE.search(text)
    if not m:
        return None
    titel = re.sub(r"\s+", " ", m.group(1)).strip()
    return titel or None


def _fehlertext(e: Exception) -> str:
    if isinstance(e, urllib.error.URLError):
        return str(e.reason)
    return str(e)


def pruefe_link(url: str, timeout: float = 10.0) -> LinkPruefung:
    """Führt genau eine HTTP-Anfrage an ``url`` aus (kein Schema-Fallback:
    ein https-Link, dessen TLS kaputt ist, bleibt ein Verbindungsfehler,
    auch wenn http:// funktionieren würde)."""
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT, "Accept": "text/html,*/*"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            status = resp.status
            endgueltige_url = resp.geturl()
            rohtext = resp.read(MAX_LESEBYTES)
    except urllib.error.HTTPError as e:
        status = e.code
        endgueltige_url = e.geturl() or url
        try:
            rohtext = e.read(MAX_LESEBYTES)
        except Exception:
            rohtext = b""
    except (urllib.error.URLError, TimeoutError, OSError, ValueError) as e:
        return LinkPruefung(url=url, fehler=_fehlertext(e), geprueft_am=time.time())

    return LinkPruefung(
        url=url,
        status_code=status,
        titel=_extrahiere_titel(rohtext),
        weitergeleitet_nach=(endgueltige_url if endgueltige_url and endgueltige_url != url else None),
        geprueft_am=time.time(),
    )


# ─────────────────────────────────────────────────────────────
# Ergebnis-Cache (JSON-Datei im Projekt)
# ─────────────────────────────────────────────────────────────

def lade_cache(pfad: Path) -> dict[str, dict]:
    if not pfad.is_file():
        return {}
    try:
        return json.loads(pfad.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {}


def speichere_cache(pfad: Path, cache: dict[str, dict]) -> None:
    pfad.parent.mkdir(parents=True, exist_ok=True)
    pfad.write_text(json.dumps(cache, ensure_ascii=False, indent=2, sort_keys=True), encoding="utf-8")


def _ist_aktuell(eintrag: dict, max_alter_stunden: float) -> bool:
    if max_alter_stunden <= 0:
        return False
    geprueft_am = eintrag.get("geprueft_am")
    if not geprueft_am:
        return False
    return (time.time() - geprueft_am) < max_alter_stunden * 3600


def _dict_aus_pruefung(p: LinkPruefung) -> dict:
    return {
        "status_code": p.status_code,
        "titel": p.titel,
        "fehler": p.fehler,
        "weitergeleitet_nach": p.weitergeleitet_nach,
        "geprueft_am": p.geprueft_am,
    }


def _pruefung_aus_dict(url: str, d: dict) -> LinkPruefung:
    return LinkPruefung(
        url=url,
        status_code=d.get("status_code"),
        titel=d.get("titel"),
        fehler=d.get("fehler"),
        weitergeleitet_nach=d.get("weitergeleitet_nach"),
        geprueft_am=d.get("geprueft_am", 0.0),
    )


# ─────────────────────────────────────────────────────────────
# Gesamtlauf
# ─────────────────────────────────────────────────────────────

def pruefe_projekt(
    projekt: Path,
    *,
    ordner: tuple[str, ...] = STANDARD_ORDNER,
    student_site: bool = False,
    timeout: float = 10.0,
    worker: int = 8,
    cache_datei: Path | None = None,
    cache_max_alter: float = 24.0,
    cache_erzwingen: bool = False,
    regeln_datei: Path | None = None,
) -> list[LinkEintrag]:
    """Sucht Markdown-Dateien, sammelt Links (dedupliziert je URL) und prüft
    jede unbekannte/veraltete URL genau einmal, nebenläufig begrenzt auf
    ``worker`` gleichzeitige Anfragen. Gibt Einträge sortiert nach Domain, URL
    zurück (siehe ``formatiere_bericht`` für die nach Domain gruppierte Ausgabe)."""
    alle_ordner = tuple(ordner) + (STUDENT_SITE_ORDNER if student_site else ())
    dateien = finde_markdown_dateien(projekt, alle_ordner)
    gesammelt = sammle_links(dateien, projekt)

    regeln_pfad = regeln_datei if regeln_datei is not None else standard_regeln_datei(projekt)
    regeln = lade_regeln(regeln_pfad)
    cache_pfad = cache_datei or (projekt / STANDARD_CACHE_NAME)
    cache = {} if cache_erzwingen else lade_cache(cache_pfad)

    eintraege: dict[str, LinkEintrag] = {}
    zu_pruefen: list[str] = []
    for url, fundstellen in gesammelt.items():
        regel = regeln.get(url)
        eintrag = LinkEintrag(
            url=url,
            fundstellen=fundstellen,
            ignoriert=bool(regel and regel.ignorieren),
            ignoriert_grund=(regel.grund if regel else ""),
            erwarteter_text=(regel.erwarteter_text if regel else ""),
        )
        eintraege[url] = eintrag
        if eintrag.ignoriert:
            continue
        cache_eintrag = cache.get(url)
        if cache_eintrag and _ist_aktuell(cache_eintrag, cache_max_alter):
            eintrag.pruefung = _pruefung_aus_dict(url, cache_eintrag)
        else:
            zu_pruefen.append(url)

    if zu_pruefen:
        with ThreadPoolExecutor(max_workers=max(1, worker)) as ex:
            ergebnisse = ex.map(lambda u: pruefe_link(u, timeout), zu_pruefen)
            for url, pruefung in zip(zu_pruefen, ergebnisse):
                eintraege[url].pruefung = pruefung
                cache[url] = _dict_aus_pruefung(pruefung)
        speichere_cache(cache_pfad, cache)

    return sorted(eintraege.values(), key=lambda e: (urlsplit(e.url).netloc, e.url))


# ─────────────────────────────────────────────────────────────
# Bericht
# ─────────────────────────────────────────────────────────────

def _formatiere_eintrag(e: LinkEintrag) -> str:
    orte = ", ".join(str(f) for f in e.fundstellen)
    if e.ignoriert:
        kopf = f"  IGNORIERT  {e.url}"
        if e.ignoriert_grund:
            kopf += f"  ({e.ignoriert_grund})"
        return f"{kopf}\n             Fundstelle: {orte}"

    p = e.pruefung
    if p is None:
        return f"  ?       {e.url}\n          Fundstelle: {orte}"

    status = f"FEHLER  {p.fehler}" if p.fehler else str(p.status_code)
    zeilen = [f"  {status:<7} {e.url}"]
    if p.weitergeleitet_nach:
        zeilen.append(f"          -> weitergeleitet nach {p.weitergeleitet_nach}")
    if p.titel:
        zeilen.append(f"          Titel: {p.titel}")
    if e.erwarteter_text:
        marker = "ABWEICHUNG" if e.text_abweichend else "ok"
        zeilen.append(f"          Erwarteter Text ({marker}): {e.erwarteter_text!r}")
    zeilen.append(f"          Fundstelle: {orte}")
    return "\n".join(zeilen)


def formatiere_bericht(eintraege: list[LinkEintrag]) -> str:
    """Baut den nach Domain gruppierten Textbericht (siehe Anforderung: stellt
    eine Seite ihre Struktur um, brechen mehrere Links derselben Domain auf
    einmal – das soll als Gruppe sichtbar sein)."""
    zeilen: list[str] = []
    aktuelle_domain: str | None = None
    tote = ignorierte = abweichende = 0

    for e in eintraege:
        domain = urlsplit(e.url).netloc or e.url
        if domain != aktuelle_domain:
            if aktuelle_domain is not None:
                zeilen.append("")
            zeilen.append(f"== {domain} ==")
            aktuelle_domain = domain
        zeilen.append(_formatiere_eintrag(e))

        if e.ignoriert:
            ignorierte += 1
        elif e.pruefung and e.pruefung.tot:
            tote += 1
        elif e.text_abweichend:
            abweichende += 1

    ok = len(eintraege) - tote - ignorierte - abweichende
    zeilen.append("")
    zeilen.append(
        f"{len(eintraege)} Link(e) geprüft: {ok} ok, {tote} tot, "
        f"{abweichende} mit abweichendem Titel, {ignorierte} ignoriert."
    )
    return "\n".join(zeilen)
