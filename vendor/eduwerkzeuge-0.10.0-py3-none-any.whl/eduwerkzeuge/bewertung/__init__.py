"""bewertung – gemeinsame Bausteine der Klausur-/Lernstandsbewertung.

Erster Baustein: der vielfach kopierte **Notenschlüssel** (Punkte → Notenpunkte
im 15-Punkte-System). Weitere Bausteine (z. B. Berichts-/CSV-Format) können
folgen.

Die umfangreiche rubrik-basierte Korrektur-Engine bleibt in der eigenständigen
Bibliothek ``klausur_bewerter`` (Klausuren/_lib) – ``bewertung`` ergänzt sie um
die kleinen, stabilen Primitive, die quer durch die Skripte dupliziert waren.

Beispiel:
    from eduwerkzeuge.bewertung import notenpunkte, note_berechnen
    notenpunkte(48, 60)            # -> 12
    note_berechnen(48, 60)         # -> "12 Punkte"
"""

from .notenschluessel import (
    NOTEN_IHK,
    NOTENPUNKTE_15,
    SCHLUESSEL,
    note_berechnen,
    noten_label,
    notenpunkte,
    parse_grenzen,
    prozent,
    schluessel_tabelle,
)

__all__ = [
    "NOTEN_IHK",
    "NOTENPUNKTE_15",
    "SCHLUESSEL",
    "note_berechnen",
    "noten_label",
    "notenpunkte",
    "parse_grenzen",
    "prozent",
    "schluessel_tabelle",
]
