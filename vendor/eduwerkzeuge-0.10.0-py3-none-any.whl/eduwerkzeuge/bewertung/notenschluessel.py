#!/usr/bin/env python3
"""
bewertung.notenschluessel – Punkte → Notenpunkte (15-Punkte-System)
===================================================================

Der in den Klausur-Korrektur-Skripten vielfach kopierte Notenschlüssel lebt
jetzt hier an *einer* Stelle. Kern ist eine reine Funktion ``notenpunkte`` (gibt
die ganze Zahl 0–15 zurück); ``note_berechnen`` liefert die früher gebräuchlichen
Beschriftungen (``"15 Punkte"`` bzw. ``"15 Punkte (1+)"``) drop-in-treu.

Der Schlüssel ist **als Daten** hinterlegt (``NOTENPUNKTE_15``) und über den
Parameter ``schluessel=`` austauschbar – andere Schwellen lassen sich ohne
Code-Änderung verwenden.

Beispiel:
    from eduwerkzeuge.bewertung import notenpunkte, note_berechnen

    notenpunkte(48, 60)                 # -> 12
    note_berechnen(48, 60)              # -> "12 Punkte"
    note_berechnen(48, 60, mit_note=True)   # -> "12 Punkte (2+)"
"""

from __future__ import annotations

# Kanonischer 15-Punkte-Schlüssel (Berufsschule / gymnasiale Oberstufe):
# (min_prozent, notenpunkte, noten_label). Absteigend sortiert; die letzte
# Zeile (0 %) fängt alles darunter ab.
NOTENPUNKTE_15: list[tuple[float, int, str]] = [
    (95, 15, "1+"), (90, 14, "1"), (85, 13, "1-"),
    (80, 12, "2+"), (75, 11, "2"), (70, 10, "2-"),
    (65, 9, "3+"), (60, 8, "3"), (55, 7, "3-"),
    (50, 6, "4+"), (45, 5, "4"), (40, 4, "4-"),
    (33, 3, "5+"), (27, 2, "5"), (20, 1, "5-"),
    (0, 0, "6"),
]


# Notenschlüssel der Kammern für Abschluss-/Zwischenprüfungen (100-Punkte-Schlüssel):
# 100–92 sehr gut, 91–81 gut, 80–67 befriedigend, 66–50 ausreichend,
# 49–30 mangelhaft, 29–0 ungenügend. 🔎 Vor Verwendung mit der zuständigen Kammer abgleichen.
NOTEN_IHK: list[tuple[float, int, str]] = [
    (92, 1, "1 (sehr gut)"), (81, 2, "2 (gut)"), (67, 3, "3 (befriedigend)"),
    (50, 4, "4 (ausreichend)"), (30, 5, "5 (mangelhaft)"), (0, 6, "6 (ungenügend)"),
]

SCHLUESSEL = {"15": NOTENPUNKTE_15, "ihk": NOTEN_IHK}


def parse_grenzen(text: str) -> list[tuple[float, int, str]]:
    """Eigener Schlüssel aus ``"92:1,81:2,67:3,50:4,30:5,0:6"`` (Prozent:Note).

    Ergebnis absteigend sortiert; eine 0-%-Stufe ist Pflicht.
    """
    stufen: list[tuple[float, int, str]] = []
    for i, teil in enumerate(t for t in text.split(",") if t.strip()):
        grenze, _, label = teil.partition(":")
        if not label.strip():
            raise ValueError(f"Stufe ohne Note: {teil!r} (Format Prozent:Note)")
        stufen.append((float(grenze.replace(",", ".")), i, label.strip()))
    stufen.sort(key=lambda x: -x[0])
    if not stufen or stufen[-1][0] != 0:
        raise ValueError("Der Schlüssel braucht eine Stufe ab 0 %.")
    if len({g for g, _, _ in stufen}) != len(stufen):
        raise ValueError("Doppelte Prozentgrenze im Schlüssel.")
    return stufen


def schluessel_tabelle(
    max_punkte: float,
    schluessel: list[tuple[float, int, str]] = NOTENPUNKTE_15,
    schritt: float = 0.5,
) -> list[dict]:
    """Vollständiger Notenschlüssel: je Stufe Prozent- und Punktbereich.

    ``ab_punkte`` = kleinste erreichbare Punktzahl (in ``schritt``-Schritten),
    die die Prozentgrenze erfüllt; ``bis_punkte`` = größte Punktzahl unterhalb
    der nächsthöheren Stufe.
    """
    import math

    def aufrunden(wert: float) -> float:
        return math.ceil(round(wert / schritt, 9)) * schritt if schritt > 0 else wert

    zeilen: list[dict] = []
    obergrenze = max_punkte
    for grenze, wert, label in schluessel:
        ab = min(aufrunden(max_punkte * grenze / 100), max_punkte)
        zeilen.append({"prozent_ab": grenze, "wert": wert, "label": label,
                       "ab_punkte": ab, "bis_punkte": obergrenze})
        obergrenze = round(ab - schritt, 6) if schritt > 0 else ab
    return zeilen


def prozent(punkte: float, max_punkte: float) -> float:
    """Prozentsatz erreichter Punkte (0.0 wenn ``max_punkte`` ≤ 0)."""
    return (punkte / max_punkte) * 100 if max_punkte else 0.0


def notenpunkte(
    punkte: float,
    max_punkte: float = 60,
    *,
    schluessel: list[tuple[float, int, str]] = NOTENPUNKTE_15,
) -> int:
    """Notenpunkte 0–15 für ``punkte`` von ``max_punkte``."""
    p = prozent(punkte, max_punkte)
    for grenze, np, _label in schluessel:
        if p >= grenze:
            return np
    return 0


def noten_label(
    punkte: float,
    max_punkte: float = 60,
    *,
    schluessel: list[tuple[float, int, str]] = NOTENPUNKTE_15,
) -> str:
    """Noten-Äquivalent als Kürzel (z. B. ``"2+"``)."""
    p = prozent(punkte, max_punkte)
    for grenze, _np, label in schluessel:
        if p >= grenze:
            return label
    return schluessel[-1][2]


def note_berechnen(
    punkte: float,
    max_punkte: float = 60,
    *,
    mit_note: bool = False,
    schluessel: list[tuple[float, int, str]] = NOTENPUNKTE_15,
) -> str:
    """Beschriftung wie in den bisherigen Korrektur-Skripten.

    ``mit_note=False`` → ``"15 Punkte"`` … ``"00 Punkte"`` (immer Plural).
    ``mit_note=True``  → ``"15 Punkte (1+)"`` … ``"00 Punkte (6)"``
    (Singular nur bei genau einem Punkt: ``"01 Punkt (5-)"``).

    Reproduziert die früheren ``note_berechnen``-Varianten zeichengenau.
    """
    np = notenpunkte(punkte, max_punkte, schluessel=schluessel)
    if not mit_note:
        return f"{np:02d} Punkte"
    label = noten_label(punkte, max_punkte, schluessel=schluessel)
    einheit = "Punkt" if np == 1 else "Punkte"
    return f"{np:02d} {einheit} ({label})"
