#!/usr/bin/env python3
"""CLI für die Bewertungs-Bausteine: ``edu-bewertung``.

  edu-bewertung note 48              # 48 von 60 Punkten -> "12 Punkte (2+)"
  edu-bewertung note 48 --max 56     # Bezug auf 56 Punkte
  edu-bewertung note 48 --schlicht   # ohne Noten-Äquivalent -> "12 Punkte"
  edu-bewertung schluessel --max 56  # vollständige Notenschlüssel-Tabelle (15-Punkte-System)
  edu-bewertung schluessel --max 100 --system ihk
  edu-bewertung schluessel --max 56 --grenzen "92:1,81:2,67:3,50:4,30:5,0:6"
"""

from __future__ import annotations

import argparse
import sys

from .notenschluessel import SCHLUESSEL, note_berechnen, notenpunkte, parse_grenzen, schluessel_tabelle


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        prog="edu-bewertung",
        description="Punkte in Notenpunkte (15-Punkte-System) umrechnen.",
    )
    sub = p.add_subparsers(dest="cmd", required=True)

    n = sub.add_parser("note", help="Punkte -> Notenpunkte")
    n.add_argument("punkte", type=float, help="erreichte Punkte")
    n.add_argument("--max", type=float, default=60, help="maximale Punkte (Standard: 60)")
    n.add_argument("--schlicht", action="store_true",
                   help="ohne Noten-Äquivalent (z. B. '12 Punkte' statt '12 Punkte (2+)')")

    k = sub.add_parser("schluessel", help="vollständige Notenschlüssel-Tabelle")
    k.add_argument("--max", type=float, required=True, help="maximale Punkte")
    k.add_argument("--system", choices=sorted(SCHLUESSEL), default="15",
                   help="15 = 15-Punkte-System (Standard), ihk = Kammer-Schlüssel")
    k.add_argument("--grenzen", default=None,
                   help='eigener Schlüssel "Prozent:Note,…", z. B. "92:1,81:2,67:3,50:4,30:5,0:6"')
    k.add_argument("--schritt", type=float, default=0.5, help="Punktschritte (Standard 0,5)")

    args = p.parse_args(argv)
    if args.cmd == "schluessel":
        try:
            schluessel = parse_grenzen(args.grenzen) if args.grenzen else SCHLUESSEL[args.system]
        except ValueError as exc:
            print(f"FEHLER: {exc}", file=sys.stderr)
            return 1
        def fmt(x: float) -> str:
            return f"{x:g}".replace(".", ",")
        print(f"| Note | ab % | Punkte (von {fmt(args.max)}) |")
        print("|---|---|---|")
        for z in schluessel_tabelle(args.max, schluessel, args.schritt):
            bereich = (f"{fmt(z['ab_punkte'])} – {fmt(z['bis_punkte'])}"
                       if z["bis_punkte"] >= z["ab_punkte"] else "– (nicht erreichbar)")
            print(f"| {z['label']} | {fmt(z['prozent_ab'])} | {bereich} |")
        return 0
    if args.cmd == "note":
        text = note_berechnen(args.punkte, args.max, mit_note=not args.schlicht)
        print(f"{text}   [{notenpunkte(args.punkte, args.max)}/15]")
        return 0
    return 1


if __name__ == "__main__":
    sys.exit(main())
