"""anonymisierung – Moodle-Schülerabgaben pseudonymisieren.

Beispiel:
    from pathlib import Path
    from eduwerkzeuge.anonymisierung import main
    main(Path("/pfad/zum/projekt"))   # Anonym/ (+ MANUELL_PRUEFEN/); Mapping in ~/.config/eduwerkzeuge/…

    # Bausteine:
    from eduwerkzeuge.anonymisierung import erstelle_mappings, anonymisiere_text
    m = erstelle_mappings(["Anna Apfel"])
    anonymisiere_text("Hallo Anna Apfel", m)
"""

from .core import (
    EXTRACT_SUFFIXE,
    TEXT_SUFFIXE,
    Mappings,
    anonymisiere_pfadname,
    anonymisiere_text,
    aufgaben_name_aus_zip,
    erstelle_mappings,
    extrahiere_text,
    extrahiere_und_anonymisiere_zip,
    finde_csv,
    ist_moodle_ordner,
    kopiere_und_anonymisiere,
    lade_mapping,
    lade_oder_erzeuge_salt,
    lade_schueler_aus_csv,
    main,
    reidentifiziere_text,
    rueckfuehren,
    schreibe_mapping,
    standard_mapping_ordner,
    parse_moodle_ordnername,
    student_aus_zip_ordner,
)

__all__ = [
    "EXTRACT_SUFFIXE",
    "TEXT_SUFFIXE",
    "Mappings",
    "anonymisiere_pfadname",
    "anonymisiere_text",
    "aufgaben_name_aus_zip",
    "erstelle_mappings",
    "extrahiere_text",
    "extrahiere_und_anonymisiere_zip",
    "finde_csv",
    "ist_moodle_ordner",
    "kopiere_und_anonymisiere",
    "lade_mapping",
    "lade_oder_erzeuge_salt",
    "lade_schueler_aus_csv",
    "main",
    "reidentifiziere_text",
    "rueckfuehren",
    "schreibe_mapping",
    "standard_mapping_ordner",
    "parse_moodle_ordnername",
    "student_aus_zip_ordner",
]
