#!/usr/bin/env python3
"""
anonymisierung – Schülerabgaben für KI-Überprüfung anonymisieren
================================================================

Entpackt Moodle-ZIP-Abgaben (oder bereits entpackte Abgabe-Ordner) und schreibt
eine vollständig anonymisierte Kopie nach ``<basis>/Anonym/``. Namen, Moodle-
Nutzernamen und E-Mail-Adressen werden durch Pseudonyme (Schueler_01 … _NN)
ersetzt – in Ordnernamen, **Dateinamen** und Dateiinhalten.

Wichtige Eigenschaften (Stand der Optimierung):
  * **Vor- UND Nachname** (auch kurze Namen) werden ersetzt, mit Wortgrenzen
    (Unterstrich/Punkt/Bindestrich zählen als Grenze) → "Anna" wird nicht in
    "Annahme" zerstört, aber "max_mustermann" wird erkannt.
  * **E-Mails domänen-unabhängig**: jede Adresse, deren lokaler Teil zu einem
    bekannten Schüler passt, wird ersetzt (nicht nur @bbs-syke.schule). Domains
    werden zusätzlich automatisch aus den Daten gesammelt; ``domains=`` kann
    überschreiben.
  * **PDF/DOCX/ODT** werden nicht mehr unverändert durchgereicht: ihr Text wird
    extrahiert, anonymisiert und als ``…__anonymisiert.txt`` beigelegt. Nicht
    extrahierbare Binärdateien (Bilder, sonstige) landen NICHT in ``Anonym/``,
    sondern in ``<basis>/MANUELL_PRUEFEN/`` mit Warnung.
  * **Nur echte Abgaben** werden verarbeitet (Moodle-Muster oder bekannter
    Schülername); projektfremde Ordner (scripts, docs, vorlagen …) werden
    ignoriert.

``basis`` Default = aktuelles Arbeitsverzeichnis. Ein Shim im Projektordner
übergibt sein eigenes Verzeichnis.

Datenschutz-Voreinstellungen (ab Version 0.2.0):
  * Das Mapping (Pseudonym ↔ echter Name) liegt standardmäßig **außerhalb** des
    Projekts unter ``~/.config/eduwerkzeuge/<projekt-kurzname>/mapping.csv``
    (Ordner 700, Datei 600). ``mapping_ziel=`` bzw. ``--mapping-ziel`` legt es
    ausdrücklich woanders ab. Umgebungsvariable ``EDUWERKZEUGE_MAPPING_DIR``
    ersetzt ``~/.config/eduwerkzeuge``.
  * Pseudonyme werden **nicht alphabetisch**, sondern in einer Reihenfolge nach
    HMAC-SHA256(salt, name) vergeben. Das Salt liegt neben dem Mapping und wird
    bei erneuten Läufen wiederverwendet → gleiche Pseudonyme; mit der Klassenliste
    allein lässt sich die Zuordnung nicht rekonstruieren.
  * Auf dem Bildschirm erscheinen **keine Klarnamen**, nur Anzahlen und Pseudonyme
    (``namen_anzeigen=True`` bzw. ``--namen`` zeigt sie bewusst an – nur lokal).
  * ``reidentifiziere_text()`` / ``--rueckfuehren`` setzt Klarnamen lokal wieder ein.

Mapping und MANUELL_PRUEFEN/ dürfen NICHT an eine KI weitergegeben werden.
"""

from __future__ import annotations

import csv
import hashlib
import hmac
import os
import re
import secrets
import shutil
import stat
import zipfile
from dataclasses import dataclass, field
from pathlib import Path

# Text-Extraktion (PDF/DOCX/ODT) lebt zentral im Modul ``dokumente``.
from ..dokumente import extrahiere_text
from ..dokumente.core import EXTRAHIERBARE_SUFFIXE as EXTRACT_SUFFIXE

# Moodle-Primitive (Ordnernamen, ZIPs, Schülerlisten) liegen zentral in ``moodle``.
from ..moodle import (
    aufgaben_name_aus_zip,
    finde_csv,
    ist_moodle_ordner,
    lade_schueler_aus_csv,
    parse_moodle_ordnername,
)
from ..moodle import bestimme_schueler_tiefe as _bestimme_schueler_tiefe
from ..moodle import normalisiere_umlaute as _normalisiere_umlaute
from ..moodle import schueler_aus_zips as _schueler_aus_zips
from ..moodle import strings_aus_zips as _strings_aus_zips


# ============================================================
# Konfiguration
# ============================================================

# Dateierweiterungen, deren Inhalt direkt als Text anonymisiert wird.
TEXT_SUFFIXE = {
    ".php", ".html", ".htm", ".css", ".js",
    ".txt", ".md", ".json", ".xml", ".csv", ".sql",
    ".py", ".java", ".c", ".cpp", ".ino", ".ts",
}

# Dateierweiterungen, deren Text extrahiert und dann anonymisiert wird,
# stammen aus ``eduwerkzeuge.dokumente`` (import als EXTRACT_SUFFIXE oben).

# Ordnernamen, die nie eine Schüler-Abgabe sind.
NICHT_ABGABE = {
    "Anonym", "SchuelerZIP", "MANUELL_PRUEFEN", "__pycache__",
    "scripts", "docs", "templates", "stylesheets", "site", "node_modules",
    "Ergebnisse", "ergebnisse", ".git", ".venv", ".pytest_cache", "diagrams",
}

# Mindestlänge, ab der ein einzelner Vor-/Nachname als ganzes Wort ersetzt wird.
MIN_BARE = 2

# Wortgrenzen: NICHT direkt neben einem alphanumerischen Zeichen
# (Unterstrich gilt dabei als Grenze, anders als \b).
_PRE = r"(?<![^\W_])"
_POST = r"(?![^\W_])"


# Namens-Hilfsfunktionen (parse_moodle_ordnername, ist_moodle_ordner,
# finde_csv, lade_schueler_aus_csv, normalisiere_umlaute) liegen jetzt zentral
# in ``eduwerkzeuge.moodle`` und werden oben importiert.


# ============================================================
# Mapping (Pseudonyme + Ersetzungsregeln)
# ============================================================

@dataclass
class Mappings:
    sortiert: list[str]                       # Originalnamen in Pseudonym-Reihenfolge
    pseudo_fuer: dict[str, str]               # Vollname -> Pseudonym
    regeln: list[tuple[re.Pattern, str]]      # geordnete (Regex, Ersatz) für Inhalt/Pfade
    ordner: dict[str, str]                    # exakte Ordner-Variante -> Pseudonym


def _reihenfolge(namen: list[str], salt: str | None) -> list[str]:
    """Reihenfolge der Pseudonymvergabe.

    ``salt=None`` → alphabetisch (Altverhalten, nur für Bibliotheksaufrufe/Tests).
    Mit ``salt`` → sortiert nach HMAC-SHA256(salt, normalisierter Name): stabil
    bei gleichem Salt, aber nicht aus der Klassenliste ableitbar.
    """
    eindeutig = sorted(set(namen), key=str.casefold)
    if salt is None:
        return eindeutig

    def schluessel(name: str) -> str:
        norm = _normalisiere_umlaute(name).casefold().strip()
        return hmac.new(salt.encode("utf-8"), norm.encode("utf-8"), hashlib.sha256).hexdigest()

    return sorted(eindeutig, key=schluessel)


def _domains_aus_strings(strings) -> set[str]:
    """Sammelt vorkommende Mail-Domains (z. B. aus Ordner-/ZIP-Namen)."""
    domains: set[str] = set()
    for s in strings:
        for m in re.finditer(r"@([\w.-]+\.\w+)", s or ""):
            domains.add(m.group(1).lower())
    return domains


def erstelle_mappings(
    vollnamen: list[str],
    domains: tuple[str, ...] | list[str] = (),
    salt: str | None = None,
) -> Mappings:
    """Baut Pseudonyme und alle Ersetzungsregeln auf.

    ``domains`` optional: zusätzliche bekannte Mail-Domains (sonst werden
    E-Mails generisch über den lokalen Teil erkannt).
    ``salt`` optional: Reihenfolge der Pseudonyme über HMAC statt alphabetisch
    (``main()`` setzt immer ein Salt).
    """
    sortiert = _reihenfolge(vollnamen, salt)
    pseudo_fuer: dict[str, str] = {}
    ordner: dict[str, str] = {}

    # Regeln nach Spezifität gruppieren (spezifisch zuerst angewendet)
    r_mail: list[tuple[re.Pattern, str]] = []
    r_moodle: list[tuple[re.Pattern, str]] = []
    r_voll: list[tuple[re.Pattern, str]] = []
    r_bare: list[tuple[int, re.Pattern, str]] = []  # (länge, regex, ersatz)

    def varianten(token: str) -> set[str]:
        return {token, _normalisiere_umlaute(token)}

    for idx, vollname in enumerate(sortiert):
        pseudo = f"Schueler_{idx + 1:02d}"
        pseudo_fuer[vollname] = pseudo
        teile = vollname.split()
        if not teile:
            continue
        vorname, nachname = teile[0], teile[-1]
        vs, ns = varianten(vorname), varianten(nachname)

        # --- E-Mail: lokaler Teil = Vor/Nachname (jede Domain) ---
        for v in vs:
            for n in ns:
                local = (
                    rf"(?:{re.escape(v)}[._]?{re.escape(n)}"
                    rf"|{re.escape(n)}[._]?{re.escape(v)})"
                )
                r_mail.append((re.compile(_PRE + local + r"@[\w.-]+", re.I),
                               f"{pseudo}@schule.de"))
            # Vorname-only-Mail (z. B. vorname@…) – nur falls eindeutig lang
            if len(v) >= 4:
                r_mail.append((re.compile(_PRE + re.escape(v) + r"@[\w.-]+", re.I),
                               f"{pseudo}@schule.de"))

        # --- Moodle-Nutzername: Vorname[Mittel]_Nachname_<domain…> ---
        for v in vs:
            for n in ns:
                r_moodle.append((
                    re.compile(_PRE + re.escape(v) + r"[A-Za-zÀ-ÿ]*_" + re.escape(n) + r"_[\w-]+", re.I),
                    pseudo,
                ))

        # --- Vollname (mit beliebigen Mittelnamen, flexible Leerzeichen) ---
        for v in vs:
            for n in ns:
                r_voll.append((
                    re.compile(_PRE + re.escape(v) + r"(?:[ \t]+[\wÀ-ÿ.\-]+)*[ \t]+" + re.escape(n) + _POST, re.I),
                    pseudo,
                ))

        # --- Bare Tokens: jeder Namensteil (Vor-, Mittel-, Nachname) ---
        for teil in teile:
            for t in varianten(teil):
                if len(t) >= MIN_BARE:
                    r_bare.append((len(t), re.compile(_PRE + re.escape(t) + _POST, re.I), pseudo))

        # --- Ordner-/Dateinamen-Varianten ---
        varbau = [
            vorname, nachname, vollname,
            "".join(teile), "_".join(teile),
        ]
        for vb in list(varbau):
            varbau.append(_normalisiere_umlaute(vb))
        for vb in varbau:
            if vb.strip():
                ordner.setdefault(vb.strip(), pseudo)

    # Reihenfolge: spezifisch -> generisch; bare Namen längste zuerst
    regeln = r_mail + r_moodle + r_voll + [
        (pat, repl) for _, pat, repl in sorted(r_bare, key=lambda x: -x[0])
    ]
    return Mappings(sortiert=sortiert, pseudo_fuer=pseudo_fuer, regeln=regeln, ordner=ordner)


def anonymisiere_text(text: str, m: Mappings) -> str:
    """Wendet alle Ersetzungsregeln auf einen Textinhalt an."""
    for pat, repl in m.regeln:
        text = pat.sub(repl, text)
    return text


def student_aus_zip_ordner(ordnername: str, m: Mappings) -> str:
    """Exaktes Pseudonym für einen Schüler-Ordnernamen (Moodle/Klartext)."""
    bereinigt = parse_moodle_ordnername(ordnername)
    for kandidat in [bereinigt, _normalisiere_umlaute(bereinigt)]:
        if kandidat in m.ordner:
            return m.ordner[kandidat]
    erster = bereinigt.split()[0] if bereinigt else ordnername
    for kandidat in [erster, _normalisiere_umlaute(erster)]:
        if kandidat in m.ordner:
            return m.ordner[kandidat]
    # Fallback: generische Ersetzung über die Regeln
    return anonymisiere_pfadname(ordnername, m)


def anonymisiere_pfadname(name: str, m: Mappings) -> str:
    """Anonymisiert einen einzelnen Pfad-Bestandteil (Ordner- oder Dateiname)."""
    bereinigt = parse_moodle_ordnername(name)
    for kandidat in [bereinigt, _normalisiere_umlaute(bereinigt)]:
        if kandidat in m.ordner:
            # Endung erhalten, falls Datei
            suffix = Path(name).suffix
            return m.ordner[kandidat] + suffix
    return anonymisiere_text(name, m)


# Das Einsammeln der Schülernamen aus Abgabe-ZIPs (bestimme_schueler_tiefe,
# aufgaben_name_aus_zip, schueler_aus_zips, strings_aus_zips) liegt jetzt zentral
# in ``eduwerkzeuge.moodle`` und wird oben importiert.


# ============================================================
# Schreiben einer (anonymisierten) Datei
# ============================================================

@dataclass
class Lauf:
    m: Mappings
    manuell_dir: Path
    warnungen: list[str] = field(default_factory=list)


def _schreibe_datei(rohdaten: bytes, suffix: str, ziel_datei: Path,
                    quell_label: str, lauf: Lauf) -> None:
    """Schreibt eine Datei anonymisiert nach ``ziel_datei``.

    Textdateien werden inline anonymisiert; PDF/DOCX/ODT werden extrahiert und
    als ``…__anonymisiert.txt`` abgelegt; nicht extrahierbare Binärdateien
    werden NICHT in die Ausgabe übernommen, sondern in MANUELL_PRUEFEN/.
    """
    s = suffix.lower()
    ziel_datei.parent.mkdir(parents=True, exist_ok=True)

    if s in TEXT_SUFFIXE:
        try:
            inhalt = rohdaten.decode("utf-8", errors="replace")
            ziel_datei.write_text(anonymisiere_text(inhalt, lauf.m), encoding="utf-8")
            return
        except Exception as exc:
            lauf.warnungen.append(f"{quell_label}: Textfehler ({exc}) → MANUELL_PRUEFEN")
            _quarantaene(rohdaten, quell_label, lauf)
            return

    if s in EXTRACT_SUFFIXE:
        text = extrahiere_text(rohdaten, s)
        if text is not None and text.strip():
            ziel_txt = ziel_datei.with_name(ziel_datei.stem + "__anonymisiert.txt")
            ziel_txt.write_text(anonymisiere_text(text, lauf.m), encoding="utf-8")
            return
        lauf.warnungen.append(
            f"{quell_label}: Text aus {s} nicht extrahierbar → MANUELL_PRUEFEN "
            f"(Original NICHT in Anonym/)"
        )
        _quarantaene(rohdaten, quell_label, lauf)
        return

    # Sonstige Binärdatei (Bild, Archiv …): NICHT durchreichen.
    lauf.warnungen.append(f"{quell_label}: Binärdatei ({s or '?'}) → MANUELL_PRUEFEN")
    _quarantaene(rohdaten, quell_label, lauf)


def _quarantaene(rohdaten: bytes, quell_label: str, lauf: Lauf) -> None:
    """Legt eine nicht-anonymisierbare Originaldatei außerhalb von Anonym/ ab."""
    ziel = lauf.manuell_dir / quell_label
    ziel.parent.mkdir(parents=True, exist_ok=True)
    try:
        ziel.write_bytes(rohdaten)
    except Exception:
        pass


# ============================================================
# Verarbeitung: ZIP und Ordner
# ============================================================

def extrahiere_und_anonymisiere_zip(zip_pfad: Path, ziel_basis: Path, lauf: Lauf) -> None:
    """Entpackt eine Moodle-Abgabe-ZIP anonymisiert nach ``ziel_basis``."""
    ziel_basis.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_pfad, "r") as zf:
        tiefe = _bestimme_schueler_tiefe(zf)
        for info in zf.infolist():
            if info.is_dir():
                continue
            teile = Path(info.filename).parts
            if not teile:
                continue
            if len(teile) >= tiefe + 2:
                pseudo = student_aus_zip_ordner(teile[tiefe], lauf.m)
                inner = [anonymisiere_pfadname(p, lauf.m) for p in teile[tiefe + 1:]]
                rest = Path(pseudo, *inner)
            else:
                rest = Path(*[anonymisiere_pfadname(p, lauf.m) for p in teile])
            ziel_datei = ziel_basis / rest
            label = str((Path(ziel_basis.name) / rest))
            _schreibe_datei(zf.read(info.filename), Path(info.filename).suffix,
                            ziel_datei, label, lauf)


def kopiere_und_anonymisiere(quelle: Path, ziel: Path, lauf: Lauf) -> None:
    """Kopiert einen Ordner rekursiv anonymisiert nach ``ziel``.

    Ordner- und Dateinamen werden anonymisiert; ``ziel`` ist bereits der
    anonymisierte Zielordner.
    """
    ziel.mkdir(parents=True, exist_ok=True)
    for eintrag in sorted(quelle.iterdir()):
        anon = anonymisiere_pfadname(eintrag.name, lauf.m)
        if eintrag.is_dir():
            kopiere_und_anonymisiere(eintrag, ziel / anon, lauf)
        else:
            ziel_datei = ziel / anon
            label = str(Path(ziel.name) / anon)
            _schreibe_datei(eintrag.read_bytes(), eintrag.suffix, ziel_datei, label, lauf)


# ============================================================
# Abgabe-Erkennung
# ============================================================

def _ist_abgabe_ordner(ordner: Path, bekannte_norm: set[str]) -> bool:
    name = ordner.name
    if name in NICHT_ABGABE or name.startswith("."):
        return False
    if ist_moodle_ordner(name):
        return True
    parsed = parse_moodle_ordnername(name)
    return _normalisiere_umlaute(parsed) in bekannte_norm


# ============================================================
# Mapping-Ablage und Rückführung
# ============================================================

def _kurzname(basis: Path) -> str:
    """Eindeutiger, lesbarer Ordnername für ein Projekt (Name + Pfad-Hash)."""
    slug = re.sub(r"[^A-Za-z0-9]+", "-", _normalisiere_umlaute(basis.name)).strip("-").lower()
    kennung = hashlib.sha1(str(basis.resolve()).encode("utf-8")).hexdigest()[:8]
    return f"{slug or 'projekt'}-{kennung}"


def standard_mapping_ordner(basis: Path) -> Path:
    """Standardablage des Mappings: ``~/.config/eduwerkzeuge/<kurzname>/``."""
    wurzel = os.environ.get("EDUWERKZEUGE_MAPPING_DIR")
    basis_dir = Path(wurzel).expanduser() if wurzel else Path.home() / ".config" / "eduwerkzeuge"
    return basis_dir / _kurzname(Path(basis))


def _sicherer_ordner(ordner: Path) -> None:
    ordner.mkdir(parents=True, exist_ok=True)
    try:
        ordner.chmod(stat.S_IRWXU)  # 700
    except OSError:
        pass


def _schreibe_privat(datei: Path, inhalt: str) -> None:
    """Schreibt eine Datei nur für den Besitzer lesbar (600)."""
    _sicherer_ordner(datei.parent)
    fd = os.open(datei, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8", newline="") as fh:
        fh.write(inhalt)
    try:
        datei.chmod(0o600)
    except OSError:
        pass


def lade_oder_erzeuge_salt(mapping_ordner: Path, salt: str | None = None) -> str:
    """Liefert das Salt des Projekts: explizit > gespeichert > neu erzeugt."""
    salt_datei = mapping_ordner / "salt.txt"
    if salt:
        _schreibe_privat(salt_datei, salt)
        return salt
    if salt_datei.exists():
        gespeichert = salt_datei.read_text(encoding="utf-8").strip()
        if gespeichert:
            return gespeichert
    neu = secrets.token_hex(16)
    _schreibe_privat(salt_datei, neu)
    return neu


def schreibe_mapping(m: Mappings, mapping_csv: Path) -> None:
    """Speichert ``Pseudonym;Echter Name`` mit Rechten 600."""
    zeilen = ["Pseudonym;Echter Name"]
    zeilen += [f"{m.pseudo_fuer[name]};{name}" for name in m.sortiert]
    _schreibe_privat(mapping_csv, "\n".join(zeilen) + "\n")


def lade_mapping(mapping_csv: Path) -> dict[str, str]:
    """Liest ein Mapping (``Pseudonym;Echter Name`` oder ``Pseudonym;Klartext_ID;…``).

    Rückgabe: Pseudonym → Klarname (bzw. Klartext-ID).
    """
    ergebnis: dict[str, str] = {}
    with open(mapping_csv, encoding="utf-8-sig", newline="") as fh:
        for zeile in csv.reader(fh, delimiter=";"):
            if len(zeile) < 2 or not zeile[0].strip() or zeile[0].strip().lower() == "pseudonym":
                continue
            ergebnis[zeile[0].strip()] = zeile[1].strip()
    return ergebnis


def reidentifiziere_text(text: str, pseudo_zu_name: dict[str, str]) -> str:
    """Setzt Klarnamen für Pseudonyme ein (nur lokal verwenden!).

    Ersetzt ``Schueler_NN@schule.de`` und ``Schueler_NN`` (bzw. jedes Pseudonym
    aus dem Mapping) an Wortgrenzen; längere Pseudonyme zuerst.
    """
    for pseudo in sorted(pseudo_zu_name, key=len, reverse=True):
        name = pseudo_zu_name[pseudo]
        text = re.sub(_PRE + re.escape(pseudo) + r"@schule\.de" + _POST, name, text)
        text = re.sub(_PRE + re.escape(pseudo) + _POST, name, text)
    return text


def rueckfuehren(pfad: Path, mapping_csv: Path, ziel: Path | None = None) -> tuple[int, int]:
    """Führt Pseudonyme in einer Textdatei oder einem Ordner auf Klarnamen zurück.

    Schreibt nach ``ziel`` (Default: ``<pfad>__klarnamen`` neben dem Original);
    das Original bleibt unverändert. Rückgabe: (Dateien, Ersetzungen).
    Gibt selbst keine Namen aus.
    """
    pfad = Path(pfad)
    zuordnung = lade_mapping(Path(mapping_csv))
    if ziel is None:
        ziel = pfad.with_name(pfad.stem + "__klarnamen" + pfad.suffix) if pfad.is_file() \
            else pfad.with_name(pfad.name + "__klarnamen")
    dateien = [pfad] if pfad.is_file() else sorted(p for p in pfad.rglob("*") if p.is_file())
    anzahl_dateien = anzahl_ersetzungen = 0
    for datei in dateien:
        if datei.suffix.lower() not in TEXT_SUFFIXE:
            continue
        rel = Path(datei.name) if pfad.is_file() else datei.relative_to(pfad)
        ziel_datei = ziel if pfad.is_file() else Path(ziel) / rel
        alt = datei.read_text(encoding="utf-8", errors="replace")
        neu = reidentifiziere_text(alt, zuordnung)
        anzahl_ersetzungen += sum(alt.count(p) for p in zuordnung)
        _schreibe_privat(Path(ziel_datei), neu)
        anzahl_dateien += 1
    return anzahl_dateien, anzahl_ersetzungen


# ============================================================
# Hauptprogramm
# ============================================================

def main(basis: Path | None = None,
         domains: tuple[str, ...] | list[str] | None = None,
         *,
         namen_anzeigen: bool = False,
         salt: str | None = None,
         mapping_ziel: Path | None = None) -> Path | None:
    """Führt die Anonymisierung im Verzeichnis ``basis`` aus (Default: cwd).

    ``domains`` optional: bekannte Mail-Domains erzwingen (sonst automatisch).
    ``namen_anzeigen``: Klarnamen auf dem Bildschirm zeigen (nur lokal!).
    ``salt``: festes Salt (sonst gespeichertes bzw. neues Salt des Projekts).
    ``mapping_ziel``: Ordner für mapping.csv (Default: ~/.config/eduwerkzeuge/…).
    Rückgabe: Pfad der mapping.csv (oder None, wenn nichts erkannt wurde).
    """
    basis = Path(basis) if basis is not None else Path.cwd()

    zip_ordner = basis if list(basis.glob("*.zip")) else basis / "SchuelerZIP"
    ausgabe = basis / "Anonym"
    manuell = basis / "MANUELL_PRUEFEN"
    mapping_ordner = Path(mapping_ziel).expanduser() if mapping_ziel else standard_mapping_ordner(basis)
    mapping_csv = mapping_ordner / "mapping.csv"
    csv_pfad = finde_csv(basis)
    abgaben_dir = basis / "Abgaben"

    print("Anonymisierung der Schülerabgaben")
    print("=" * 40)

    zip_dateien = sorted(zip_ordner.glob("*.zip")) if zip_ordner.is_dir() else []

    # 1. Schülernamen sammeln (CSV > ZIPs > erkannte Abgabe-Ordner)
    vollnamen: list[str] = []
    if csv_pfad and csv_pfad.exists():
        vollnamen = lade_schueler_aus_csv(csv_pfad)
        print(f"  {len(vollnamen)} Schüler aus CSV: {csv_pfad}")

    if zip_dateien:
        for n in _schueler_aus_zips(zip_dateien):
            if n not in vollnamen:
                vollnamen.append(n)

    # Quelle der Ordner-Abgaben bestimmen
    if abgaben_dir.is_dir():
        kandidaten = [p for p in abgaben_dir.iterdir() if p.is_dir()]
    else:
        kandidaten = [p for p in basis.iterdir()
                      if p.is_dir() and p.name not in NICHT_ABGABE and not p.name.startswith(".")]

    bekannte_norm = {_normalisiere_umlaute(n) for n in vollnamen}
    # Namen aus Moodle-Ordnern ergänzen (auch ohne CSV)
    for p in kandidaten:
        if ist_moodle_ordner(p.name):
            nm = parse_moodle_ordnername(p.name)
            if nm and _normalisiere_umlaute(nm) not in bekannte_norm:
                vollnamen.append(nm)
                bekannte_norm.add(_normalisiere_umlaute(nm))

    if not vollnamen:
        print("FEHLER: Keine Schüler erkannt (keine CSV, keine Moodle-ZIPs/-Ordner).")
        return None

    # 2. Domains bestimmen (automatisch + Override)
    domain_set: set[str] = set(domains or ())
    domain_set |= _domains_aus_strings([p.name for p in kandidaten])
    domain_set |= _domains_aus_strings(_strings_aus_zips(zip_dateien))

    # 3. Mappings + Lauf-Kontext
    projekt_salt = lade_oder_erzeuge_salt(mapping_ordner, salt)
    m = erstelle_mappings(vollnamen, tuple(sorted(domain_set)), salt=projekt_salt)
    lauf = Lauf(m=m, manuell_dir=manuell)

    # 4. Ausgabe vorbereiten
    if ausgabe.exists():
        shutil.rmtree(ausgabe)
    ausgabe.mkdir()
    if manuell.exists():
        shutil.rmtree(manuell)

    # 5. Verarbeiten
    if zip_dateien:
        print(f"  ZIP-Modus: {len(zip_dateien)} ZIP(s) in {zip_ordner.name}/\n")
        for zip_pfad in zip_dateien:
            aufgabe = anonymisiere_pfadname(aufgaben_name_aus_zip(zip_pfad), m)
            print(f"  {zip_pfad.name}  →  {ausgabe.name}/{aufgabe}/")
            extrahiere_und_anonymisiere_zip(zip_pfad, ausgabe / aufgabe, lauf)
    else:
        abgaben = sorted(p for p in kandidaten if _ist_abgabe_ordner(p, bekannte_norm))
        ignoriert = sorted(p.name for p in kandidaten if not _ist_abgabe_ordner(p, bekannte_norm))
        if not abgaben:
            print("  WARNUNG: Keine Abgabe-Ordner erkannt.")
        print(f"  Ordner-Modus: {len(abgaben)} Abgabe(n)"
              + (f", {len(ignoriert)} ignoriert ({', '.join(ignoriert)})" if ignoriert else "") + "\n")
        for quelle in abgaben:
            anon = student_aus_zip_ordner(quelle.name, m)
            herkunft = quelle.name if namen_anzeigen else "Abgabe"
            print(f"  {herkunft}  →  {ausgabe.name}/{anon}/")
            kopiere_und_anonymisiere(quelle, ausgabe / anon, lauf)

    # 6. Mapping speichern (Rechte 600, außerhalb des Projekts)
    try:
        schreibe_mapping(m, mapping_csv)
    except Exception as exc:
        print(f"  ⚠  Fehler beim Schreiben von mapping.csv: {exc}")

    # 7. Zusammenfassung – Klarnamen nur auf ausdrücklichen Wunsch
    print(f"\n{len(m.sortiert)} Pseudonym(e) vergeben "
          f"({m.pseudo_fuer[m.sortiert[0]]} … {m.pseudo_fuer[m.sortiert[-1]]}).")
    if namen_anzeigen:
        print("Pseudonyme (nur lokal anzeigen!):")
        for name in m.sortiert:
            print(f"  {m.pseudo_fuer[name]}  ←→  {name}")
    if domain_set:
        print(f"  Erkannte Mail-Domains: {len(domain_set)}")
    alt_mapping = basis / "mapping.csv"
    if alt_mapping.exists() and alt_mapping.resolve() != mapping_csv.resolve():
        print(f"\n  ⚠  Alte Zuordnung im Projektordner gefunden: {alt_mapping}"
              "\n     Bitte prüfen und löschen oder an einen sicheren Ort verschieben.")

    if lauf.warnungen:
        print(f"\n  ⚠  {len(lauf.warnungen)} Datei(en) nicht automatisch anonymisierbar "
              f"→ {manuell.name}/ (NICHT an die KI geben!):")
        for wmsg in lauf.warnungen:
            print(f"     - {wmsg}")

    print("\nFertig!")
    print(f"  Anonymisierte Abgaben : {ausgabe}")
    if lauf.warnungen:
        print(f"  Manuell prüfen        : {manuell}")
    print(f"  Zuordnung (nur Lehrer): {mapping_csv}  (Rechte 600)")
    print("\nHINWEIS: mapping.csv und MANUELL_PRUEFEN/ NICHT an die KI weitergeben.")
    return mapping_csv
