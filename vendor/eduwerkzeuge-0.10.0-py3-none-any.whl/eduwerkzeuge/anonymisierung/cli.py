#!/usr/bin/env python3
"""CLI für die Anonymisierung: ``edu-anonymisieren [VERZEICHNIS]``.

  edu-anonymisieren ./Abgaben                 # Anonym/ + Mapping in ~/.config/eduwerkzeuge/…
  edu-anonymisieren ./Abgaben --namen         # Zuordnung zusätzlich auf dem Bildschirm (nur lokal!)
  edu-anonymisieren ./Abgaben --mapping-ziel ./privat   # Mapping ausdrücklich woanders ablegen
  edu-anonymisieren ./Abgaben --rueckfuehren 04_korrektur   # Pseudonyme lokal → Klarnamen
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from .core import main as _run
from .core import rueckfuehren, standard_mapping_ordner


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="edu-anonymisieren",
        description="Moodle-Schülerabgaben pseudonymisieren (Anonym/ + Mapping außerhalb des Projekts).",
    )
    parser.add_argument(
        "verzeichnis",
        nargs="?",
        default=None,
        help="Arbeitsverzeichnis (Default: aktuelles Verzeichnis).",
    )
    parser.add_argument("--namen", action="store_true",
                        help="Zuordnung Pseudonym ↔ Klarname auf dem Bildschirm zeigen (nur lokal!).")
    parser.add_argument("--salt", default=None,
                        help="festes Salt für reproduzierbare Pseudonyme (sonst gespeichertes/neues).")
    parser.add_argument("--mapping-ziel", default=None, type=Path,
                        help="Ordner für mapping.csv (Default: ~/.config/eduwerkzeuge/<projekt>/).")
    parser.add_argument("--rueckfuehren", default=None, type=Path, metavar="PFAD",
                        help="Pseudonyme in Datei/Ordner PFAD lokal durch Klarnamen ersetzen "
                             "(Kopie '…__klarnamen'; Original bleibt).")
    parser.add_argument("--ausgabe", default=None, type=Path,
                        help="Ziel für --rueckfuehren (Default: neben PFAD mit Suffix __klarnamen).")
    args = parser.parse_args(argv)
    basis = Path(args.verzeichnis) if args.verzeichnis else Path.cwd()

    if args.rueckfuehren:
        mapping_ordner = args.mapping_ziel.expanduser() if args.mapping_ziel else standard_mapping_ordner(basis)
        mapping_csv = mapping_ordner / "mapping.csv"
        if not mapping_csv.exists():
            print(f"FEHLER: Kein Mapping gefunden: {mapping_csv}", file=sys.stderr)
            return 1
        dateien, ersetzungen = rueckfuehren(args.rueckfuehren, mapping_csv, args.ausgabe)
        print(f"Rückführung: {dateien} Datei(en), {ersetzungen} Pseudonym-Vorkommen ersetzt.")
        print("HINWEIS: Die Dateien mit Klarnamen NICHT an eine KI weitergeben.")
        return 0

    _run(basis, namen_anzeigen=args.namen, salt=args.salt, mapping_ziel=args.mapping_ziel)
    return 0


if __name__ == "__main__":
    sys.exit(main())
